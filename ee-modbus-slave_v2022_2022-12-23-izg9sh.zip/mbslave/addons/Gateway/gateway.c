/*
 * MODBUS Library: Luminary Cortex M3, FreeRTOS and lwIP Example
 * Copyright (c) 2010 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: gateway.c,v 1.4 2010-06-13 17:05:53 embedded-so.embedded-solutions.1 Exp $
 */

/* ----------------------- System includes ----------------------------------*/
#include <inc/hw_memmap.h>
#include <inc/hw_types.h>
#include <inc/hw_ints.h>
#include <inc/hw_sysctl.h>
#include <driverlib/gpio.h>
#include <driverlib/sysctl.h>
#include <driverlib/interrupt.h>
#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>
#include "lwip/api.h"

/* ----------------------- Platform includes --------------------------------*/
#include "netif/LWIPStack.h"
#include "netif/ETHIsr.h"
#include "utils/uartstdio.h"
#include "port/mbport.h"
#include "mbs.h"
#include "mbm.h"
#include "common/mbportlayer.h"
#include "common/mbutils.h"
/* ----------------------- Modbus includes ----------------------------------*/

/* ----------------------- Defines ------------------------------------------*/
#define DEBUG_TASK_PRIORITY             ( tskIDLE_PRIORITY + 2 )
#define DEBUG_TASK_STACKSIZE            ( configMINIMAL_STACK_SIZE )
#define MASTER_TASK_PRIORITY            ( tskIDLE_PRIORITY + 2 )
#define MASTER_TASK_STACKSIZE           ( 256 )
#define SLAVE_TASK_PRIORITY             ( tskIDLE_PRIORITY + 2 )
#define SLAVE_TASK_STACKSIZE            ( 256 )

#define MBS_LISTEN_ADDRESS              "0.0.0.0"       /* Bind on all addresses */
#define MBS_LISTEN_PORT                 502

#define MBM_SERIAL_PORT			        ( 0 )
#define MBM_SERIAL_BAUDRATE		        ( 57600 )
#define MBM_SERIAL_PARITY		        ( MB_PAR_NONE )

#define TEST1_SLAVE_ADDRESS             ( 10 )
#define TEST1_HOLDING_REG_START         ( 512 )
#define TEST1_HOLDING_REG_LENGTH        ( 10 )

#define GATEWAY_TIMEOUT                 ( 500 )

/* ----------------------- Type definitions ---------------------------------*/
typedef struct
{
    UBYTE           ubSlaveAddress;
    UBYTE          *pubMBPDU;
    USHORT         *pusMBPDULength;
} xMsgSlaveRequest;

typedef struct
{
    eMBErrorCode    eStatus;
} xMsgSlaveResponse;

/* ----------------------- Static variables ---------------------------------*/
STATIC xMBSHandle xMBSHdl;
STATIC xQueueHandle xGatewayRequestQueueHdl;
STATIC xQueueHandle xGatewayResponseQueueHdl;

STATIC USHORT   usRegHoldingValue[32];
STATIC USHORT   usRegInputValue[32];
/* ----------------------- External prototypes ------------------------------*/

/* ----------------------- Static functions ---------------------------------*/
void            vDebugTask( void *pvParameters );
void            vMasterTask( void *pvParameters );
void            vSlaveTask( void *pvParameters );
STATIC eMBException eMyRegInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs );
STATIC eMBException eMyRegHoldingCB( UBYTE * pubRegBuffer, USHORT usAddress,
                                     USHORT usNRegs, eMBSRegisterMode eRegMode );
STATIC          eMBException eMyGatewayCB( UBYTE ubSlaveAddress, UBYTE * pubMBPDU, USHORT * pusMBPDULength );

/* ----------------------- Start implementation -----------------------------*/

int
main( void )
{
    if( DEVICE_IS_REVA2 )
    {
        SysCtlLDOSet( SYSCTL_LDO_2_75V );
    }
    /* Set the clocking to run from the PLL at 50 MHz */
    SysCtlClockSet( SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_8MHZ );
#if defined( PART_LM3S6965 ) || defined( PART_LM3S8962 )
    SysCtlPeripheralEnable( SYSCTL_PERIPH_UART0 );
    SysCtlPeripheralEnable( SYSCTL_PERIPH_UART1 );
    SysCtlPeripheralEnable( SYSCTL_PERIPH_UART2 );
    SysCtlPeripheralEnable( SYSCTL_PERIPH_GPIOA );
    SysCtlPeripheralEnable( SYSCTL_PERIPH_GPIOB );
    SysCtlPeripheralEnable( SYSCTL_PERIPH_GPIOC );
    SysCtlPeripheralEnable( SYSCTL_PERIPH_GPIOD );
    SysCtlPeripheralEnable( SYSCTL_PERIPH_GPIOE );
    SysCtlPeripheralEnable( SYSCTL_PERIPH_GPIOF );
    SysCtlPeripheralEnable( SYSCTL_PERIPH_GPIOG );
#else
#error "unsupported part"
#endif

    xGatewayRequestQueueHdl = xQueueCreate( 1, sizeof( xMsgSlaveRequest ) );
    xGatewayResponseQueueHdl = xQueueCreate( 1, sizeof( xMsgSlaveResponse ) );
    if( ( NULL == xGatewayRequestQueueHdl ) || ( NULL == xGatewayResponseQueueHdl ) )
    {
    }
    if( pdTRUE !=
        xTaskCreate( vDebugTask, ( signed portCHAR * )"DEBUG", DEBUG_TASK_STACKSIZE, NULL, DEBUG_TASK_PRIORITY, NULL ) )
    {
    }
    else if( pdTRUE !=
             xTaskCreate( vMasterTask, ( signed portCHAR * )"MASTER", MASTER_TASK_STACKSIZE, NULL, MASTER_TASK_PRIORITY,
                          NULL ) )
    {
    }
    else if( NULL == sys_thread_new( "MODBUS", vSlaveTask, NULL, SLAVE_TASK_STACKSIZE, SLAVE_TASK_PRIORITY ) )
    {
    }
    else
    {
        vMBPInit(  );
        vTaskStartScheduler(  );
    }
}

void
vDebugTask( void *pvParameters )
{
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
    static char     arubBuffer[512];
#endif
    for( ;; )
    {
        vTaskDelay( 5000 );
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
        vTaskList( ( signed char * )arubBuffer );
        vMBPPortLog( MB_LOG_ERROR, MB_LOG_PORT_OTHER, "%s", arubBuffer );
#endif
    }
}

void
vMasterTask( void *pvParameters )
{
    xMsgSlaveRequest xSlaveRequest;
    xMsgSlaveResponse xSlaveResponse;
    xMBMHandle      xMBMHdl;
    eMBErrorCode    eStatus, eStatus2;
    UBYTE           ubMBPDULength;
    for( ;; )
    {
        if( MB_ENOERR !=
            ( eStatus2 = eMBMSerialInit( &xMBMHdl, MB_RTU, MBM_SERIAL_PORT, MBM_SERIAL_BAUDRATE, MBM_SERIAL_PARITY ) ) )
        {
            eStatus = eStatus2;
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
            vMBPPortLog( MB_LOG_ERROR, MB_LOG_PORT_OTHER, "Can not initialize MODBUS master stack: %d!\n",
                         ( int )eStatus );
#endif
        }
        else
        {
            do
            {
                if( pdTRUE == xQueueReceive( xGatewayRequestQueueHdl, &xSlaveRequest, portMAX_DELAY ) )
                {
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
                    vMBPPortLog( MB_LOG_ERROR, MB_LOG_PORT_OTHER, "processing request message...\n" );
#endif
                    eStatus = eMBMReadWriteRAWPDU( xMBMHdl, xSlaveRequest.ubSlaveAddress,
                                                   xSlaveRequest.pubMBPDU[0],
                                                   &( xSlaveRequest.pubMBPDU[1] ),
                                                   *( xSlaveRequest.pusMBPDULength ) - 1,
                                                   &( xSlaveRequest.pubMBPDU[1] ), 252, &ubMBPDULength );
                    *( xSlaveRequest.pusMBPDULength ) = ubMBPDULength + 1;
                    xSlaveResponse.eStatus = eStatus;
                    ( void )xQueueSend( xGatewayResponseQueueHdl, &xSlaveResponse, 0 );
                }

            }
            while( TRUE );
        }
        if( eStatus != MB_ENOERR )
        {
            /* Give other tasks a chance to run. */
            vTaskDelay( 500 );
        }
    }
}


void
vSlaveTask( void *pvParameters )
{
    IP_CONFIG       ipconfig;

    eMBErrorCode    eStatus, eStatus2;
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
    vMBPPortLog( MB_LOG_DEBUG, MB_LOG_PORT_OTHER, "Starting lwIP\n" );
#endif

    ETHServiceTaskInit( 0 );
    ETHServiceTaskFlush( 0, ETH_FLUSH_RX | ETH_FLUSH_TX );
    ipconfig.IPMode = IPADDR_USE_STATIC;
    ipconfig.IPAddr = 0xC0A86465UL;
    ipconfig.NetMask = 0xFFFFFF00UL;
    ipconfig.GWAddr = 0x00000000UL;
    LWIPServiceTaskInit( &ipconfig );

    for( ;; )
    {
        if( MB_ENOERR != ( eStatus2 = eMBSTCPInit( &xMBSHdl, MBS_LISTEN_ADDRESS, MBS_LISTEN_PORT ) ) )
        {
            eStatus = eStatus2;
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
            vMBPPortLog( MB_LOG_ERROR, MB_LOG_PORT_OTHER,
                         "Failed to startup MODBUS slave stack on %s:%hu. Failed with %d!\n", MBS_LISTEN_ADDRESS,
                         ( USHORT ) MBS_LISTEN_PORT, ( int )eStatus );
#endif
        }

        else
        {
            if( MB_ENOERR != ( eStatus2 = eMBSTCPSetGatewayMode( xMBSHdl, TRUE ) ) )
            {
                eStatus = eStatus2;
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
                vMBPPortLog( MB_LOG_ERROR, MB_LOG_PORT_OTHER, "Can not enable gateway mode: %d!\n", ( int )eStatus );
#endif
            }
            if( MB_ENOERR != ( eStatus2 = eMBSRegisterGatewayCB( xMBSHdl, eMyGatewayCB ) ) )
            {
                eStatus = eStatus2;
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
                vMBPPortLog( MB_LOG_ERROR, MB_LOG_PORT_OTHER, "Can not register gateway callback: %d!\n",
                             ( int )eStatus );
#endif
            }

            else if( MB_ENOERR != ( eStatus = eMBSRegisterInputCB( xMBSHdl, eMyRegInputCB ) ) )
            {
                eStatus = eStatus2;
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
                vMBPPortLog( MB_LOG_ERROR, MB_LOG_PORT_OTHER, "Can not register input registers. Failed with %d!\n",
                             ( int )eStatus );
#endif
            }
            else if( MB_ENOERR != ( eStatus = eMBSRegisterHoldingCB( xMBSHdl, eMyRegHoldingCB ) ) )
            {
                eStatus = eStatus2;
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
                vMBPPortLog( MB_LOG_ERROR, MB_LOG_PORT_OTHER, "Can not register holding registers. Failed with %d!\n",
                             ( int )eStatus );
#endif
            }
            else
            {
                do
                {
                    /* Poll the communication stack. */
                    if( MB_ENOERR != ( eStatus2 = eMBSPoll( xMBSHdl ) ) )
                    {
                        eStatus = eStatus2;
                    }
                }
                while( MB_ENOERR == eStatus );

            }
            if( MB_ENOERR != ( eStatus2 = eMBSClose( xMBSHdl ) ) )
            {
                eStatus = eStatus2;
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
                vMBPPortLog( MB_LOG_ERROR, MB_LOG_PORT_OTHER, "Can not close MODBUS stack. Status = %d!\n",
                             ( int )eStatus );
#endif
            }
        }
        if( MB_ENOERR != eStatus )
        {
            /* Give OS some time to cleanup. A longer waiting time here is
             * recommended since when the socket is closed the lwIP stack
             * does not immediately allow a new listening socket on this
             * address.
             */
            vTaskDelay( 500 );
        }
    }

}


eMBException
eMyRegInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs )
{
    eMBException    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
    STATIC const ULONG usRegsMappedAt = 0x0100;
    ULONG           usRegStart = usAddress;
    ULONG           usRegEnd = usAddress + usNRegs - 1;
    USHORT          usIndex;
    USHORT          usIndexEnd;

    if( ( usNRegs > 0 ) &&
        ( usRegStart >= usRegsMappedAt ) && ( usRegEnd <= ( usRegsMappedAt + MB_UTILS_NARRSIZE( usRegInputValue ) ) ) )
    {
        usIndex = ( USHORT ) ( usRegStart - usRegsMappedAt );
        usIndexEnd = ( USHORT ) ( usRegEnd - usRegsMappedAt );
        for( ; usIndex <= usIndexEnd; usIndex++ )
        {
            *pubRegBuffer++ = ( UBYTE ) ( usRegInputValue[usIndex] >> 8 );
            *pubRegBuffer++ = ( UBYTE ) ( usRegInputValue[usIndex] & 0xFF );
        }
        eException = MB_PDU_EX_NONE;
    }
    return eException;
}

eMBException
eMyRegHoldingCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs, eMBSRegisterMode eRegMode )
{
    eMBException    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
    STATIC const ULONG usRegsMappedAt = 0x0200;
    ULONG           usRegStart = usAddress;
    ULONG           usRegEnd = usAddress + usNRegs - 1;
    USHORT          usIndex;
    USHORT          usIndexEnd;

    if( ( usNRegs > 0 ) &&
        ( usRegStart >= usRegsMappedAt )
        && ( usRegEnd <= ( usRegsMappedAt + MB_UTILS_NARRSIZE( usRegHoldingValue ) ) ) )
    {
        usIndex = ( USHORT ) ( usRegStart - usRegsMappedAt );
        usIndexEnd = ( USHORT ) ( usRegEnd - usRegsMappedAt );
        switch ( eRegMode )
        {
        case MBS_REGISTER_WRITE:
            for( ; usIndex <= usIndexEnd; usIndex++ )
            {
                usRegHoldingValue[usIndex] = ( USHORT ) * pubRegBuffer++ << 8;
                usRegHoldingValue[usIndex] |= ( USHORT ) * pubRegBuffer++;
            }
            break;

        default:
        case MBS_REGISTER_READ:

            for( ; usIndex <= usIndexEnd; usIndex++ )
            {
                *pubRegBuffer++ = ( UBYTE ) ( usRegHoldingValue[usIndex] >> 8 );
                *pubRegBuffer++ = ( UBYTE ) ( usRegHoldingValue[usIndex] & 0xFF );
            }
            break;
        }
        eException = MB_PDU_EX_NONE;
    }
    return eException;
}

eMBException
eMyGatewayCB( UBYTE ubSlaveAddress, UBYTE * pubMBPDU, USHORT * pusMBPDULength )
{
    xMsgSlaveRequest xSlaveRequest;
    xMsgSlaveResponse xSlaveResponse;
    eMBException    eException = MB_PDU_EX_NONE;
    /* Check if there is an old message - If yes drain them */
    while( uxQueueMessagesWaiting( xGatewayResponseQueueHdl ) )
    {
        ( void )xQueueReceive( xGatewayResponseQueueHdl, &xSlaveResponse, 0 );
    }
    xSlaveRequest.ubSlaveAddress = ubSlaveAddress;
    xSlaveRequest.pubMBPDU = pubMBPDU;
    xSlaveRequest.pusMBPDULength = pusMBPDULength;
    if( pdTRUE == xQueueSend( xGatewayRequestQueueHdl, &xSlaveRequest, 0 ) )
    {
        if( pdTRUE == xQueueReceive( xGatewayResponseQueueHdl, &xSlaveResponse, GATEWAY_TIMEOUT / portTICK_RATE_MS ) )
        {
            if( MB_ENOERR == xSlaveResponse.eStatus )
            {
                eException = MB_PDU_EX_NONE;
            }
            else
            {
                eException = eMBErrorcodeToException( xSlaveResponse.eStatus );
            }
        }
        else
        {
            eException = MB_PDU_EX_GATEWAY_PATH_UNAVAILABLE;
        }
    }
    else
    {
        eException = MB_PDU_EX_SLAVE_BUSY;
    }
    return eException;
}

#if 0
eMBException
eMyRegHoldingCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs, eMBSRegisterMode eRegMode )
{
    eMBException    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
    UBYTE           ubSlaveAddress;
    xMsgSlaveRequest xSlaveRequest;
    xMsgSlaveResponse xSlaveResponse;
    if( MB_ENOERR == eMBSGetRequestSlaveAddress( xMBSHdl, &ubSlaveAddress ) )
    {
#if defined( MBP_ENABLE_DEBUG_FACILITY ) && ( MBP_ENABLE_DEBUG_FACILITY == 1 )
        vMBPPortLog( MB_LOG_ERROR, MB_LOG_PORT_OTHER, "%s holding registers (start=%hu, nregs=%hu, address=%d)\n",
                     eRegMode == MBS_REGISTER_WRITE ? "write" : "read", usAddress, usNRegs, ( int )ubSlaveAddress );
#endif
        if( ( 0xFF == ubSlaveAddress ) || ( 0x00 == ubSlaveAddress ) )
        {
            /* These registers are handled locally. */
            eException = eMyRegHoldingCBLocal( pubRegBuffer, usAddress, usNRegs, eRegMode );
        }
        else
        {
            xSlaveRequest.eMode = eRegMode == MBS_REGISTER_WRITE ? WRITE_HOLDING : READ_HOLDING;
            xSlaveRequest.usAddress = usAddress;
            xSlaveRequest.usNRegs = usNRegs;
            xSlaveRequest.pubBuffer = pubRegBuffer;
            xSlaveRequest.ubSlaveAddress = ubSlaveAddress;
            /* Check if there is an old message - If yes drain this one */
            while( uxQueueMessagesWaiting( xGatewayResponseQueueHdl ) )
            {
                ( void )xQueueReceive( xGatewayResponseQueueHdl, &xSlaveResponse, 0 );
            }
            if( pdTRUE == xQueueSend( xGatewayRequestQueueHdl, &xSlaveRequest, 0 ) )
            {
                if( pdTRUE ==
                    xQueueReceive( xGatewayResponseQueueHdl, &xSlaveResponse, GATEWAY_TIMEOUT / portTICK_RATE_MS ) )
                {
                    if( MB_ENOERR == xSlaveResponse.eStatus )
                    {
                        eException = MB_PDU_EX_NONE;
                    }
                    else
                    {
                        eException = eMBErrorcodeToException( xSlaveResponse.eStatus );
                    }
                }
                else
                {
                    eException = MB_PDU_EX_GATEWAY_PATH_UNAVAILABLE;
                }
            }
            else
            {
                eException = MB_PDU_EX_SLAVE_BUSY;
            }
        }
    }
    return eException;
}
#endif

void
vApplicationStackOverflowHook( xTaskHandle * pxTask, signed portCHAR * pcTaskName )
{
    ( void )IntMasterDisable(  );
    /* Let the watchdog trigger a reset here. */
    for( ;; );
}

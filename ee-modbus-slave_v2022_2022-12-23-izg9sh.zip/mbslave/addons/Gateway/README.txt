 
                  MODBUS TCP / Serial Gateway
                  ===========================

Description:
============

Example project for implementing a MODBUS TCP/RTU gateway. This project uses 
the Cortex M3/FreeRTOS/lwIP port but it should be fairly simply to port it 
to different platforms.

Compilation: 
============
You have to get a license of the MODBUS master stack. The source folder 'mbmaster'
should be copied into the root directory of the slave stack so that you have
the following root directory structure

 - addons
 - demo
 - doc
 - mbmaster
 - mbslave
 - tests
 - tools
 - Changelog.txt



 
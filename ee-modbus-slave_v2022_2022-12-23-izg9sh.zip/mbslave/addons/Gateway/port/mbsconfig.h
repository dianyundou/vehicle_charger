/* 
 * MODBUS Slave Library: Luminary Cortex M3, FreeRTOS and lwIP Example
 * Copyright (c) 2009 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: mbsconfig.h,v 1.2 2010-06-13 17:05:54 embedded-so.embedded-solutions.1 Exp $
 */

#ifndef _MBSCONFIG_H
#define _MBSCONFIG_H

#ifdef __cplusplus
PR_BEGIN_EXTERN_C
#endif

/* ----------------------- Defines ------------------------------------------*/
#define MBS_SERIAL_API_VERSION                  ( 2 )
#define MBS_ASCII_ENABLED                       ( 0 )
#define MBS_ASCII_WAITAFTERSEND_ENABLED	        ( 0 )

#define MBS_RTU_ENABLED                         ( 0 )
#define MBS_RTU_WAITAFTERSEND_ENABLED	        ( 0 )
#define MBS_SERIAL_APIV2_RTU_DYNAMIC_TIMEOUT_MS( ulBaudRate ) \
	usMPSerialTimeout( ulBaudRate )

#define MBS_TCP_ENABLED                         ( 1 )
#define MBS_TCP_MAX_INSTANCES                   ( 1 )
#define MBS_NCUSTOM_FUNCTION_HANDLERS           ( 8 )
#define MBS_ENABLE_DEBUG_FACILITY               ( 0 )

#define MBS_TRACK_SLAVEADDRESS                  ( 0 )
#define MBS_ENABLE_GATEWAY_MODE                 ( 1 )

#ifdef __cplusplus
PR_END_EXTERN_C
#endif

#endif

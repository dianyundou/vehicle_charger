/* 
 * Description: Generic utility functions.
 * Copyright (c) 2008 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: utils.h,v 1.1 2009-01-06 13:51:31 cwalter Exp $
 */

#ifndef _UTILS_H
#define _UTILS_H

#ifdef __cplusplus
PR_BEGIN_EXTERN_C
#endif

/* ----------------------- Defines ------------------------------------------*/
#define UTILS_NARRSIZE( x )         ( sizeof( x ) / sizeof( ( x )[ 0 ] ) )
#define SYS_EVHDL_INVALID           ( NULL )

/* ----------------------- Type definitions ---------------------------------*/

typedef enum
{
    EV_ENOERR = 0x00,
    EV_EINVAL = 0x01,
    EV_ENORES = 0x02
} eEvErrorCode;

typedef void   *xEvHdl;

/* ----------------------- Function prototypes ------------------------------*/
eEvErrorCode    xEvInit( xEvHdl * pxEvHdl );
eEvErrorCode    xEvClose( xEvHdl xEvHdlArg );
eEvErrorCode    xSysEventSet( xEvHdl xEvHdlArg, UBYTE ubEvIdx );
eEvErrorCode    xSysEventClear( xEvHdl xEvHdlArg, UBYTE ubEvIdx );
BOOL            xSysEventIsSet( xEvHdl xEvHdlArg, UBYTE ubEvIdx );

#ifdef __cplusplus
PR_END_EXTERN_C
#endif

#endif

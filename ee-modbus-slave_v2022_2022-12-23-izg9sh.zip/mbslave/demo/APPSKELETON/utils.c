/* 
 * Utils: System functions
 * Copyright (c) 2008 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: utils.c,v 1.1 2009-01-06 13:51:31 cwalter Exp $
 */

/* ----------------------- System includes ----------------------------------*/
#include <stdlib.h>

/* ----------------------- Platform includes --------------------------------*/
#include "mbport.h"
#include "utils.h"

/* ----------------------- Modbus includes ----------------------------------*/

/* ----------------------- Defines ------------------------------------------*/
#define IDX_INVALID         255

#define IS_VALID_HDL( pxHdl, arHdls ) \
    ( ( pxHdl != NULL ) && ( pxHdl->ubIdx < UTILS_NARRSIZE( arHdls ) ) && \
      ( pxHdl == &arHdls[ pxHdl->ubIdx ] ) )

/* ----------------------- Type definitions ---------------------------------*/

/* ----------------------- Static variables ---------------------------------*/
STATIC BOOL     bIsEvInitialized = FALSE;

/* ----------------------- Static functions ---------------------------------*/

/* ----------------------- Start implementation -----------------------------*/
typedef struct
{
    UBYTE           ubIdx;
    ULONG           usEventMask;
} xEvIntHdl_t;

STATIC xEvIntHdl_t xEvIntHdls[1];

eEvErrorCode
xEvInit( xEvHdl * pxEvHdl )
{
    eEvErrorCode    eStatus = EV_ENORES;
    UBYTE           ubIdx;

    MBP_ENTER_CRITICAL_SECTION(  );
    if( !bIsEvInitialized )
    {
        for( ubIdx = 0; ubIdx < UTILS_NARRSIZE( xEvIntHdls ); ubIdx++ )
        {
            xEvIntHdls[ubIdx].ubIdx = IDX_INVALID;
            xEvIntHdls[ubIdx].usEventMask = 0;
        }

    }
    for( ubIdx = 0; ubIdx < UTILS_NARRSIZE( xEvIntHdls ); ubIdx++ )
    {
        if( IDX_INVALID == xEvIntHdls[ubIdx].ubIdx )
        {
            xEvIntHdls[ubIdx].ubIdx = ubIdx;
            xEvIntHdls[ubIdx].usEventMask = 0;
            *pxEvHdl = &xEvIntHdls[ubIdx];
            eStatus = EV_ENOERR;
            break;
        }
    }

    MBP_EXIT_CRITICAL_SECTION(  );
    return eStatus;
}

eEvErrorCode
xEvClose( xEvHdl xEvHdlArg )
{
    eEvErrorCode    eStatus = EV_EINVAL;
    xEvIntHdl_t    *pxEvHdl = xEvHdlArg;

    if( IS_VALID_HDL( pxEvHdl, xEvIntHdls ) )
    {
        pxEvHdl->ubIdx = IDX_INVALID;
        pxEvHdl->usEventMask = 0;
        eStatus = EV_ENOERR;
    }

    return eStatus;
}


eEvErrorCode
xSysEventSet( xEvHdl xEvHdlArg, UBYTE ubEvIdx )
{
    eEvErrorCode    eStatus = EV_EINVAL;
    xEvIntHdl_t    *pxEvHdl = xEvHdlArg;

    if( IS_VALID_HDL( pxEvHdl, xEvIntHdls ) &&
        ( ubEvIdx > 0 ) && ( ubEvIdx <= ( UBYTE ) ( 8 * sizeof( pxEvHdl->usEventMask ) ) ) )
    {
        pxEvHdl = xEvHdlArg;
        pxEvHdl->usEventMask |= ( 1UL << ( ubEvIdx - 1 ) );
        eStatus = EV_ENOERR;
    }
    return eStatus;
}

eEvErrorCode
xSysEventClear( xEvHdl xEvHdlArg, UBYTE ubEvIdx )
{
    eEvErrorCode    eStatus = EV_EINVAL;
    xEvIntHdl_t    *pxEvHdl = xEvHdlArg;

    if( IS_VALID_HDL( pxEvHdl, xEvIntHdls ) &&
        ( ubEvIdx > 0 ) && ( ubEvIdx <= ( UBYTE ) ( 8 * sizeof( pxEvHdl->usEventMask ) ) ) )
    {
        pxEvHdl = xEvHdlArg;
        pxEvHdl->usEventMask &= ~( 1UL << ( ubEvIdx - 1 ) );
        eStatus = EV_ENOERR;
    }
    return eStatus;
}

BOOL
xSysEventIsSet( xEvHdl xEvHdlArg, UBYTE ubEvIdx )
{
    BOOL            bIsSet = FALSE;
    xEvIntHdl_t    *pxEvHdl = xEvHdlArg;

    if( IS_VALID_HDL( pxEvHdl, xEvIntHdls ) &&
        ( ubEvIdx > 0 ) && ( ubEvIdx <= ( UBYTE ) ( 8 * sizeof( pxEvHdl->usEventMask ) ) ) )
    {
        bIsSet = pxEvHdl->usEventMask & ( 1UL << ( ubEvIdx - 1 ) ) ? TRUE : FALSE;
    }
    return bIsSet;
}

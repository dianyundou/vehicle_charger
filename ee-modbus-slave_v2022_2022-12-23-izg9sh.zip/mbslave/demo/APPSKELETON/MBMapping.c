/* 
 * MODBUS Utilities
 * Copyright (c) 2008 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: MBMapping.c,v 1.1 2009-01-06 13:51:31 cwalter Exp $
 */

/* ----------------------- System includes ----------------------------------*/
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "mbport.h"
#include "mbs.h"

/* ----------------------- Module includes ----------------------------------*/

#include "MBMapping.h"

/* ----------------------- Defines ------------------------------------------*/

void
vMBUSHORT2MB( USHORT usValue, UBYTE ** ppubMBPDU )
{
    MBP_ASSERT( NULL != ppubMBPDU );
    MBP_ASSERT( NULL != *ppubMBPDU );
    **ppubMBPDU = ( UBYTE ) ( usValue >> 8U );
    *ppubMBPDU += 1;
    **ppubMBPDU = ( UBYTE ) ( usValue & 0xFF );
    *ppubMBPDU += 1;

}

void
vMBFLOAT2MB( float fValue, UBYTE ** ppubMBPDU )
{
    UBYTE          *pbValue = ( UBYTE * ) & fValue;

    MBP_ASSERT( NULL != ppubMBPDU );
    MBP_ASSERT( NULL != *ppubMBPDU );


    **ppubMBPDU = *( pbValue + 3 );
    *ppubMBPDU += 1;
    **ppubMBPDU = *( pbValue + 2 );
    *ppubMBPDU += 1;
    **ppubMBPDU = *( pbValue + 1 );
    *ppubMBPDU += 1;
    **ppubMBPDU = *( pbValue + 0 );
    *ppubMBPDU += 1;
}

void
vMBSTR2MB( const char *pcStr, USHORT usByteOffset, USHORT usByteSizeRequested, UBYTE ** ppubMBPDU )
{
    USHORT          usStrLen;
    USHORT          usByteCurPos;

    MBP_ASSERT( NULL != pcStr );
    usStrLen = ( USHORT ) strlen( pcStr );
    for( usByteCurPos = usByteOffset; usByteCurPos < ( usByteOffset + usByteSizeRequested ); usByteCurPos++ )
    {
        if( usByteCurPos < usStrLen )
        {
            **ppubMBPDU = ( UBYTE ) * ( pcStr + usByteCurPos );
        }
        else
        {
            **ppubMBPDU = ' ';
        }
        *ppubMBPDU += 1;
    }
}

void
vMBMB2FLOAT( UBYTE ** ppubMBPDU, float *pfValue )
{
    UBYTE          *pbValue = ( UBYTE * ) pfValue;

    MBP_ASSERT( NULL != ppubMBPDU );
    MBP_ASSERT( NULL != *ppubMBPDU );
    MBP_ASSERT( NULL != pfValue );

    *( pbValue + 3 ) = **ppubMBPDU;
    *ppubMBPDU += 1;
    *( pbValue + 2 ) = **ppubMBPDU;
    *ppubMBPDU += 1;
    *( pbValue + 1 ) = **ppubMBPDU;
    *ppubMBPDU += 1;
    *( pbValue + 0 ) = **ppubMBPDU;
    *ppubMBPDU += 1;
}

void
vMBMB2USHORT( UBYTE ** ppubMBPDU, USHORT * pusValue )
{
    MBP_ASSERT( NULL != ppubMBPDU );
    MBP_ASSERT( NULL != pusValue );
    *pusValue = ( USHORT ) ( ( USHORT ) ** ppubMBPDU << 8U );
    *ppubMBPDU += 1;
    *pusValue |= ( USHORT ) ** ppubMBPDU;
    *ppubMBPDU += 1;
}

void
vMBMB2CHAR( UBYTE ** ppubMBPDU, CHAR * pucValue, USHORT usByteLength )
{
    USHORT          ubIdx;

    MBP_ASSERT( NULL != ppubMBPDU );
    MBP_ASSERT( NULL != pucValue );
    for( ubIdx = 0; ubIdx < usByteLength; ubIdx++ )
    {
        *pucValue++ = ( CHAR ) ** ppubMBPDU;
        *ppubMBPDU += 1;
    }
    *pucValue = '\0';
}

/* 
 * MODBUS Application Skeleton
 * Copyright (c) 2008 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: demo.c,v 1.2 2009-01-06 13:53:02 cwalter Exp $
 */

/* ----------------------- System includes ----------------------------------*/
#include <stdlib.h>
#include <math.h>
#include <string.h>

/* ----------------------- Platform includes --------------------------------*/
#include "mbport.h"
#include "mbs.h"
#include "utils.h"
#include "MBMapping.h"

/* ----------------------- Defines ------------------------------------------*/
#define SYS_DEFAULT_MODE                        ( MB_RTU )
#define SYS_DEFAULT_SERIAL_BAUDRATE             ( 38400 )
#define SYS_DEFAULT_PARITY                      ( MB_PAR_ODD )
#define SYS_DEFAULT_SLAVE_ADDRESS               ( 9 )
#define SYS_DEFAULT_SERIAL                      "00000001"
#define SYS_SERIAL_PORT                         ( 1 )
/* ----------------------- Type definitions ---------------------------------*/

typedef struct
{
    char            arcSerialNumber[9];
    eMBSerialMode   eMBCurMode;
    eMBSerialParity eMBCurParity;
    UBYTE           ubMBCurSlaveAddress;
    ULONG           ulMBCurBaudRate;
    USHORT          usRebootCounter;
} xConfig_t;

typedef enum
{
    STATE_INIT_CFG,
    STATE_INIT_MB,
    STATE_INIT_MODULES,
    STATE_EXEC_MEASURE,
    STATE_EXEC_MODBUS,
    STATE_EXEC_STATUS,
    STATE_SLEEP,
    STATE_CLOSE
} eSystemStates_t;

/* ----------------------- Static variables ---------------------------------*/
STATIC xEvHdl   xMBProtEventHdl;
STATIC xConfig_t xCurConfig;

static USHORT   uiMBErrorReg;
static float    fMBParameter1;
static const USHORT uiMBSWVersion = 0x0100;
static const USHORT uiMBHWVersion = 0x0100;

/* *INDENT-OFF* */
static const xMBProtRegMapping_t xInputRegs[] = {
    {0x0000, 1, NULL, MBPROT_REGTYPE_USHORT, SYS_EV_NONE, ( void * )&uiMBSWVersion},
    {0x0001, 1, NULL, MBPROT_REGTYPE_USHORT, SYS_EV_NONE, ( void * )&uiMBHWVersion},
    {0x0002, 1, NULL, MBPROT_REGTYPE_USHORT, SYS_EV_NONE, ( void * )&uiMBErrorReg},
    {0x0003, 2, NULL, MBPROT_REGTYPE_FLOAT, SYS_EV_NONE, ( void * )&fMBParameter1}
};

static const xMBProtRegMapping_t xHoldingRegs[] = {
    /* Device configuration public. */
    {0x0000, 1, NULL, MBPROT_REGTYPE_SPECIAL_MBADDRESS, SYS_EV_CONFIG_CHANGED,( void * )&xCurConfig.ubMBCurSlaveAddress},
    {0x0001, 1, NULL, MBPROT_REGTYPE_SPECIAL_MBMODE, SYS_EV_CONFIG_CHANGED, ( void * )&xCurConfig.eMBCurMode},
    {0x0002, 1, NULL, MBPROT_REGTYPE_SPECIAL_MBBAUDRATE, SYS_EV_CONFIG_CHANGED, ( void * )&xCurConfig.ulMBCurBaudRate},
    {0x0003, 1, NULL, MBPROT_REGTYPE_SPECIAL_MBPARITY, SYS_EV_CONFIG_CHANGED, ( void * )&xCurConfig.eMBCurParity}
};
/* *INDENT-ON* */

/* ----------------------- Static functions ---------------------------------*/
STATIC eMBException eMyRegInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs );
STATIC eMBException eMyRegHoldingCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs,
                                     eMBSRegisterMode eRegMode );

STATIC void     vSystemLoadCfg( xConfig_t * pxConfig );
STATIC void     vSystemStoreCfg( xConfig_t * pxConfig );

/* ----------------------- Start implementation -----------------------------*/
int
main( void )
{
    eSystemStates_t eCurrentState = STATE_INIT_CFG;
    eMBErrorCode    eStatus;
    xMBSHandle      xMBSHdl;

    vMBPOtherDLLInit(  );
    /* Load the current system configuration after restart and update
     * the reboot counter.
     */
    vSystemLoadCfg( &xCurConfig );
    xCurConfig.usRebootCounter++;
    vSystemStoreCfg( &xCurConfig );

    do
    {
        switch ( eCurrentState )
        {
        case STATE_INIT_CFG:
            vSystemLoadCfg( &xCurConfig );

            if( EV_ENOERR != xEvInit( &xMBProtEventHdl ) )
            {
                MBP_ASSERT( 0 );
            }

            eCurrentState = STATE_INIT_MB;
            break;

        case STATE_INIT_MB:
            eStatus = eMBSSerialInit( &xMBSHdl, xCurConfig.eMBCurMode, xCurConfig.ubMBCurSlaveAddress,
                                      SYS_SERIAL_PORT, xCurConfig.ulMBCurBaudRate, xCurConfig.eMBCurParity );
            if( MB_ENOERR != eStatus )
            {
                /* Can't initialize MODBUS stack. Reset to defaults. */
                xCurConfig.eMBCurMode = SYS_DEFAULT_MODE;
                xCurConfig.ubMBCurSlaveAddress = SYS_DEFAULT_SLAVE_ADDRESS;
                xCurConfig.ulMBCurBaudRate = SYS_DEFAULT_SERIAL_BAUDRATE;
                xCurConfig.eMBCurParity = SYS_DEFAULT_PARITY;
                /* Save and reset the system. */
                vSystemStoreCfg( &xCurConfig );
                eCurrentState = STATE_INIT_CFG;

            }
            else if( MB_ENOERR != ( eStatus = eMBSRegisterInputCB( xMBSHdl, eMyRegInputCB ) ) )
            {
                eStatus = eMBSClose( xMBSHdl );
                MBP_ASSERT( MB_ENOERR == eStatus );
            }
            else if( MB_ENOERR != ( eStatus = eMBSRegisterHoldingCB( xMBSHdl, eMyRegHoldingCB ) ) )
            {
                eStatus = eMBSClose( xMBSHdl );
                MBP_ASSERT( MB_ENOERR == eStatus );
            }
            else
            {
                eCurrentState = STATE_INIT_MODULES;
            }
            break;

        case STATE_INIT_MODULES:
            /* Initialize your hardware here. */
            eCurrentState = STATE_EXEC_MEASURE;
            break;

        case STATE_EXEC_MEASURE:
            eCurrentState = STATE_EXEC_STATUS;
            break;

        case STATE_EXEC_STATUS:
            eCurrentState = STATE_EXEC_MODBUS;

            if( xSysEventIsSet( xMBProtEventHdl, SYS_EV_CONFIG_CHANGED ) )
            {
                xSysEventClear( xMBProtEventHdl, SYS_EV_CONFIG_CHANGED );
                /* Store the new system configuration. */
                vSystemStoreCfg( &xCurConfig );
                eCurrentState = STATE_CLOSE;
            }            
            break;

        case STATE_EXEC_MODBUS:
            /* Poll the communication stack. */
            eStatus = eMBSPoll( xMBSHdl );
            if( MB_ENOERR != eStatus )
            {
                eCurrentState = STATE_CLOSE;
            }
            else
            {
                eCurrentState = STATE_SLEEP;
            }
            break;

        case STATE_SLEEP:
            eCurrentState = STATE_EXEC_MEASURE;
            break;

        case STATE_CLOSE:
            if( MB_HDL_INVALID != xMBSHdl )
            {
                eStatus = eMBSClose( xMBSHdl );
                xMBSHdl = MB_HDL_INVALID;
                MBP_ASSERT( MB_ENOERR == eStatus );
            }
            if( SYS_EVHDL_INVALID != xMBProtEventHdl )
            {
                if( EV_ENOERR != xEvClose( xMBProtEventHdl ) )
                {
                    MBP_ASSERT( 0 );
                }
                xMBProtEventHdl = NULL;
            }
            eCurrentState = STATE_INIT_CFG;
            break;

        default:
            MBP_ASSERT( 0 );
            break;
        }
    }
    while( TRUE );

    return 0;
}

void
vRegInputGetMapping( USHORT usIndex, const xMBProtRegMapping_t * pxBasePtr, xMBProtRegMapping_t * pxRegMapping )
{
    /* You might want to load the register mapping from ROM so you
     * can adapt this function.
     */
    memcpy( pxRegMapping, &pxBasePtr[usIndex], sizeof( xMBProtRegMapping_t ) );
}

eMBException
eReadRegisters( UBYTE ** ppubRegBuffer, USHORT usAddress, USHORT usNRegs,
                const xMBProtRegMapping_t * pxRegMapping, USHORT usNRegsMapped )
{
    eMBException    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
    USHORT          usRegCur = usAddress;
    USHORT          usRegEnd = usAddress + usNRegs;
    USHORT          usCurRegStartAddress, usCurRegEndAddress;
    USHORT          usCurRegSizeMax;
    USHORT          usLastRegEnd = 0;
    xMBProtRegMapping_t xRegMappingCur;
    USHORT          usIndex = 0, usIndex2;

    union
    {
        char            cValue;
        UBYTE           ubValue;
        USHORT          usValue;
        ULONG           ulValue;
        float           fValue;
    } xTempRegs;

    for( usIndex = 0; usIndex < usNRegsMapped; usIndex++ )
    {
        vRegInputGetMapping( usIndex, pxRegMapping, &xRegMappingCur );
        /* First check if the register is enabled. It is enabled if the
         * enable pointer is not set ot if it is set the value is true.
         */
        if( xRegMappingCur.pbIsEnabled == NULL || *xRegMappingCur.pbIsEnabled )
        {
            usCurRegStartAddress = xRegMappingCur.usRegAddress;
            usCurRegEndAddress = xRegMappingCur.usRegAddress + xRegMappingCur.usLength;
            if( ( usRegCur >= usCurRegStartAddress ) && ( usRegCur < usCurRegEndAddress ) )
            {
                usLastRegEnd = usCurRegStartAddress;
                /* We found our start register */
                break;
            }
        }
    }

    /* Check if we have found our start register. If not we can not return
     * any registers. 
     */
    if( usIndex != usNRegsMapped )
    {
        for( ; usIndex < usNRegsMapped; usIndex++ )
        {
            vRegInputGetMapping( usIndex, pxRegMapping, &xRegMappingCur );
            usCurRegStartAddress = xRegMappingCur.usRegAddress;
            usCurRegEndAddress = xRegMappingCur.usRegAddress + xRegMappingCur.usLength;

            /* Check if the register block is continous. */
            if( usLastRegEnd == xRegMappingCur.usRegAddress )
            {
                /* Update usLastReg to point to the end of the last register 
                 * read. */
                usLastRegEnd = usCurRegEndAddress;
                /* If a user does not want all register from a block
                 * compute the number of registers needed.
                 */
                usCurRegSizeMax = usRegEnd - usCurRegStartAddress;
                if( usCurRegSizeMax > xRegMappingCur.usLength )
                {
                    usCurRegSizeMax = xRegMappingCur.usLength;
                }

                /* If a register is disabled we return zeros for it. */
                if( xRegMappingCur.pbIsEnabled != NULL && !( *xRegMappingCur.pbIsEnabled ) )
                {
                    for( usIndex2 = 0; usIndex2 < usCurRegSizeMax; usIndex2++ )
                    {
                        **ppubRegBuffer = 0;
                        *ppubRegBuffer += 1;
                        **ppubRegBuffer = 0;
                        *ppubRegBuffer += 1;

                    }
                }
                else
                {
                    switch ( xRegMappingCur.eType )
                    {
                    case MBPROT_REGTYPE_RESERVED:
                        for( usIndex2 = 0; usIndex2 < usCurRegSizeMax; usIndex2++ )
                        {
                            **ppubRegBuffer = 0;
                            *ppubRegBuffer += 1;
                            **ppubRegBuffer = 0;
                            *ppubRegBuffer += 1;

                        }
                        break;
                    case MBPROT_REGTYPE_USHORT:
                        MBP_ASSERT( NULL != xRegMappingCur.pvData );
                        xTempRegs.usValue = *( USHORT * ) xRegMappingCur.pvData;
                        vMBUSHORT2MB( xTempRegs.usValue, ppubRegBuffer );
                        break;

                    case MBPROT_REGTYPE_CHAR:
                        vMBSTR2MB( ( const char * )xRegMappingCur.pvData, 0, usCurRegSizeMax * 2, ppubRegBuffer );
                        break;

                    case MBPROT_REGTYPE_FLOAT:
                        xTempRegs.fValue = *( float * )xRegMappingCur.pvData;
                        vMBFLOAT2MB( xTempRegs.fValue, ppubRegBuffer );
                        break;

                    case MBPROT_REGTYPE_SPECIAL_MBADDRESS:
                        MBP_ASSERT( NULL != xRegMappingCur.pvData );
                        xTempRegs.usValue = *( UBYTE * ) xRegMappingCur.pvData;
                        vMBUSHORT2MB( xTempRegs.usValue, ppubRegBuffer );
                        break;

                    case MBPROT_REGTYPE_SPECIAL_MBMODE:
                        MBP_ASSERT( NULL != xRegMappingCur.pvData );
                        switch ( *( eMBSerialMode * ) xRegMappingCur.pvData )
                        {
                        case MB_RTU:
                            xTempRegs.usValue = MBPROT_MODE_RTU;
                            break;
                        case MB_ASCII:
                            xTempRegs.usValue = MBPROT_MODE_ASCII;
                            break;
                        default:
                            xTempRegs.usValue = MBPROT_MODE_RTU;
                            MBP_ASSERT( 0 );
                            break;
                        }
                        vMBUSHORT2MB( xTempRegs.usValue, ppubRegBuffer );
                        break;

                    case MBPROT_REGTYPE_SPECIAL_MBBAUDRATE:
                        MBP_ASSERT( NULL != xRegMappingCur.pvData );
                        switch ( *( ULONG * ) xRegMappingCur.pvData )
                        {
                        case 9600:
                            xTempRegs.usValue = MBPROT_BAUDRATE_9600;
                            break;
                        case 19200:
                            xTempRegs.usValue = MBPROT_BAUDRATE_19200;
                            break;
                        case 38400:
                            xTempRegs.usValue = MBPROT_BAUDRATE_38400;
                            break;
                        case 57600:
                            xTempRegs.usValue = MBPROT_BAUDRATE_57600;
                            break;
                        case 115200:
                            xTempRegs.usValue = MBPROT_BAUDRATE_115200;
                            break;
                        default:
                            xTempRegs.usValue = MBPROT_BAUDRATE_9600;
                            MBP_ASSERT( 0 );
                            break;
                        }
                        vMBUSHORT2MB( xTempRegs.usValue, ppubRegBuffer );
                        break;

                    case MBPROT_REGTYPE_SPECIAL_MBPARITY:
                        MBP_ASSERT( NULL != xRegMappingCur.pvData );
                        switch ( *( eMBSerialParity * ) xRegMappingCur.pvData )
                        {
                        case MB_PAR_NONE:
                            xTempRegs.usValue = MBPROT_PARITY_NONE;
                            break;
                        case MB_PAR_EVEN:
                            xTempRegs.usValue = MBPROT_PARITY_EVEN;
                            break;
                        case MB_PAR_ODD:
                            xTempRegs.usValue = MBPROT_PARITY_ODD;
                            break;
                        default:
                            xTempRegs.usValue = MBPROT_PARITY_NONE;
                            MBP_ASSERT( 0 );
                            break;
                        }
                        vMBUSHORT2MB( xTempRegs.usValue, ppubRegBuffer );
                        break;

                    default:
                        MBP_ASSERT( 0 );
                        break;
                    }
                }

                /* Check if we have read all required registers for this
                 * request. If yes then finish.
                 */
                if( usCurRegEndAddress >= usRegEnd )
                {
                    eException = MB_PDU_EX_NONE;
                    break;
                }
            }
            else
            {
                eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
                break;
            }
        }
    }

    return eException;
}

eMBException
eMyRegInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs )
{
    return eReadRegisters( &pubRegBuffer, usAddress, usNRegs, xInputRegs, UTILS_NARRSIZE( xInputRegs ) );
}


eMBException
eMyRegHoldingCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs, eMBSRegisterMode eRegMode )
{
    eEvErrorCode    eEvStatus;
    eMBException    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
    USHORT          usRegCur = usAddress;
    USHORT          usRegEnd = usAddress + usNRegs;
    USHORT          usCurRegStartAddress, usCurRegEndAddress;
    USHORT          usLastRegEnd = 0;
    xMBProtRegMapping_t xRegMappingCur;
    USHORT          usIndex = 0;
    BOOL            bWriteWasValid;

    union
    {
        char            cValue;
        UBYTE           ubValue;
        USHORT          usValue;
        float           fValue;
    } xTempRegs;

    if( MBS_REGISTER_READ == eRegMode )
    {
        eException = eReadRegisters( &pubRegBuffer, usAddress, usNRegs, xHoldingRegs, UTILS_NARRSIZE( xHoldingRegs ) );
    }
    else
    {
        for( usIndex = 0; usIndex < UTILS_NARRSIZE( xHoldingRegs ); usIndex++ )
        {
            vRegInputGetMapping( usIndex, xHoldingRegs, &xRegMappingCur );
            /* First check if the register is enabled. It is enabled if the
             * enable pointer is not set ot if it is set the value is true.
             */
            if( xRegMappingCur.pbIsEnabled == NULL || *xRegMappingCur.pbIsEnabled )
            {
                if( usRegCur == xRegMappingCur.usRegAddress )
                {
                    usLastRegEnd = usRegCur;
                    /* We found our start register */
                    break;
                }
            }
        }
        /* Check if we have found our start register. If not we can not return
         * any registers. 
         */
        if( usIndex != UTILS_NARRSIZE( xHoldingRegs ) )
        {
            for( ; usIndex < UTILS_NARRSIZE( xHoldingRegs ); usIndex++ )
            {
                vRegInputGetMapping( usIndex, xHoldingRegs, &xRegMappingCur );
                if( xRegMappingCur.pbIsEnabled == NULL || *xRegMappingCur.pbIsEnabled )
                {
                    usCurRegStartAddress = xRegMappingCur.usRegAddress;
                    usCurRegEndAddress = xRegMappingCur.usRegAddress + xRegMappingCur.usLength;

                    /* Check if the register block is continous. */
                    if( usLastRegEnd == xRegMappingCur.usRegAddress )
                    {
                        /* Update usLastReg to point to the end of the last register 
                         * read. */
                        usLastRegEnd = usCurRegEndAddress;
                        bWriteWasValid = FALSE;
                        if( usCurRegEndAddress <= usRegEnd )
                        {
                            switch ( xRegMappingCur.eType )
                            {
                            case MBPROT_REGTYPE_SPECIAL_MBADDRESS:
                                vMBMB2USHORT( &pubRegBuffer, &xTempRegs.usValue );
                                if( ( xTempRegs.usValue >= MBPROT_MBADDRESS_MIN )
                                    && ( xTempRegs.usValue <= MBPROT_MBADDRESS_MAX ) )
                                {
                                    *( UBYTE * ) xRegMappingCur.pvData = ( UBYTE ) xTempRegs.usValue;
                                    bWriteWasValid = TRUE;
                                }
                                break;

                            case MBPROT_REGTYPE_SPECIAL_MBMODE:
                                vMBMB2USHORT( &pubRegBuffer, &xTempRegs.usValue );
                                if( MBPROT_MODE_RTU == xTempRegs.usValue )
                                {
                                    *( eMBSerialMode * ) xRegMappingCur.pvData = MB_RTU;
                                    bWriteWasValid = TRUE;
                                }
                                else if( MBPROT_MODE_ASCII == xTempRegs.usValue )
                                {
                                    *( eMBSerialMode * ) xRegMappingCur.pvData = MB_ASCII;
                                    bWriteWasValid = TRUE;
                                }
                                break;

                            case MBPROT_REGTYPE_SPECIAL_MBBAUDRATE:
                                vMBMB2USHORT( &pubRegBuffer, &xTempRegs.usValue );
                                switch ( ( eMBProtBaudrate_t ) xTempRegs.usValue )
                                {
                                case MBPROT_BAUDRATE_9600:
                                    *( ULONG * ) xRegMappingCur.pvData = 9600UL;
                                    bWriteWasValid = TRUE;
                                    break;
                                case MBPROT_BAUDRATE_19200:
                                    *( ULONG * ) xRegMappingCur.pvData = 19200UL;
                                    bWriteWasValid = TRUE;
                                    break;
                                case MBPROT_BAUDRATE_38400:
                                    *( ULONG * ) xRegMappingCur.pvData = 38400UL;
                                    bWriteWasValid = TRUE;
                                    break;
                                default:
                                    break;
                                }
                                break;

                            case MBPROT_REGTYPE_SPECIAL_MBPARITY:
                                vMBMB2USHORT( &pubRegBuffer, &xTempRegs.usValue );
                                switch ( ( eMBProtParity_t ) xTempRegs.usValue )
                                {
                                case MBPROT_PARITY_NONE:
                                    *( eMBSerialParity * ) xRegMappingCur.pvData = MB_PAR_NONE;
                                    bWriteWasValid = TRUE;
                                    break;
                                case MBPROT_PARITY_EVEN:
                                    *( eMBSerialParity * ) xRegMappingCur.pvData = MB_PAR_EVEN;
                                    bWriteWasValid = TRUE;
                                    break;
                                case MBPROT_PARITY_ODD:
                                    *( eMBSerialParity * ) xRegMappingCur.pvData = MB_PAR_ODD;
                                    bWriteWasValid = TRUE;
                                default:
                                    break;
                                }
                                break;

                            case MBPROT_REGTYPE_CHAR:
                                vMBMB2CHAR( &pubRegBuffer, ( CHAR * ) xRegMappingCur.pvData,
                                            xRegMappingCur.usLength * 2 );
                                bWriteWasValid = TRUE;
                                break;

                            case MBPROT_REGTYPE_FLOAT:
                                MBP_ASSERT( NULL != xRegMappingCur.pvData );
                                vMBMB2FLOAT( &pubRegBuffer, ( float * )xRegMappingCur.pvData );
                                bWriteWasValid = TRUE;
                                break;

                            case MBPROT_REGTYPE_USHORT:
                                MBP_ASSERT( NULL != xRegMappingCur.pvData );
                                vMBMB2USHORT( &pubRegBuffer, ( USHORT * ) xRegMappingCur.pvData );
                                bWriteWasValid = TRUE;
                                break;

                            default:
                                MBP_ASSERT( 0 );
                                break;
                            }
                            if( bWriteWasValid && ( SYS_EV_NONE != xRegMappingCur.eEvent ) )
                            {
                                eEvStatus = xSysEventSet( xMBProtEventHdl, xRegMappingCur.eEvent );
                                MBP_ASSERT( EV_ENOERR == eEvStatus );
                            }
                        }
                        else
                        {
                            /* Abort - We do not support partial writes to registers. */
                            eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
                            break;
                        }
                    }
                    else
                    {
                        /* Abort - No more registers mapped here. */
                        eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
                        break;
                    }
                    /* Check if we have read all required registers for this
                     * request. If yes then finish.
                     */
                    if( usCurRegEndAddress == usRegEnd )
                    {
                        eException = MB_PDU_EX_NONE;
                        break;
                    }
                }
                else
                {
                    /* Abort - No more registers mapped here. */
                    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
                    break;
                }
            }
        }
    }
    return eException;
}

STATIC void
vSystemLoadCfg( xConfig_t * pxConfig )
{
    /* Not implemented - Use defaults */
    pxConfig->eMBCurMode = SYS_DEFAULT_MODE;
    pxConfig->ubMBCurSlaveAddress = SYS_DEFAULT_SLAVE_ADDRESS;
    pxConfig->ulMBCurBaudRate = SYS_DEFAULT_SERIAL_BAUDRATE;
    pxConfig->eMBCurParity = SYS_DEFAULT_PARITY;
    pxConfig->usRebootCounter = 0;
}

STATIC void
vSystemStoreCfg( xConfig_t * pxConfig )
{
    /* Not implemented */
}

/* 
 * MODBUS Utilities
 * Copyright (c) 2008 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: mbmapping.h,v 1.2 2009-01-06 13:53:02 cwalter Exp $
 */

#ifndef _MBMAPPING_H
#define _MBMAPPING_H

#ifdef __cplusplus
PR_BEGIN_EXTERN_C
#endif

/* ----------------------- Defines ------------------------------------------*/
#define MBPROT_MBADDRESS_MIN            ( 1 )
#define MBPROT_MBADDRESS_MAX            ( 247 )

/* ----------------------- Type definitions ---------------------------------*/
typedef enum
{
    MBPROT_MODE_RTU = 0,
    MBPROT_MODE_ASCII = 1,
    MBPROT_MODE_TCP = 2
} xMBProtModes_t;

typedef enum
{
    MBPROT_BAUDRATE_9600 = 0,
    MBPROT_BAUDRATE_19200 = 1,
    MBPROT_BAUDRATE_38400 = 2,
    MBPROT_BAUDRATE_57600 = 3,
    MBPROT_BAUDRATE_115200 = 4
} eMBProtBaudrate_t;

typedef enum
{
    MBPROT_PARITY_NONE = 0,
    MBPROT_PARITY_EVEN = 1,
    MBPROT_PARITY_ODD = 2
} eMBProtParity_t;

typedef enum
{
    MBPROT_REGTYPE_RESERVED,
    MBPROT_REGTYPE_USHORT,
    MBPROT_REGTYPE_ENUM,
    MBPROT_REGTYPE_FLOAT,
    MBPROT_REGTYPE_CHAR,
    MBPROT_REGTYPE_SPECIAL_MBADDRESS,
    MBPROT_REGTYPE_SPECIAL_MBMODE,
    MBPROT_REGTYPE_SPECIAL_MBBAUDRATE,
    MBPROT_REGTYPE_SPECIAL_MBPARITY,
} eMBProtRegType_t;

typedef enum
{
    SYS_EV_NONE = 0,
    SYS_EV_CONFIG_CHANGED = 1,
} eMBProtRegEvents_t;


typedef struct
{
    USHORT          usRegAddress;
    USHORT          usLength;
    BOOL           *pbIsEnabled;
    eMBProtRegType_t eType;
    eMBProtRegEvents_t eEvent;
    void           *pvData;
} xMBProtRegMapping_t;

/* ----------------------- Function prototypes ------------------------------*/
void            vMBUSHORT2MB( USHORT usValue, UBYTE ** ppubMBPDU );
void            vMBFLOAT2MB( float fValue, UBYTE ** ppubMBPDU );
void            vMBSTR2MB( const char *pcStr, USHORT usByteOffset, USHORT usByteLength, UBYTE ** ppubMBPDU );
void            vMBMB2FLOAT( UBYTE ** ppubMBPDU, float *pfValue );
void            vMBMB2USHORT( UBYTE ** ppubMBPDU, USHORT * pusValue );
void            vMBMB2CHAR( UBYTE ** ppubMBPDU, CHAR * pucValue, USHORT usByteLength );

#ifdef __cplusplus
PR_END_EXTERN_C
#endif

#endif

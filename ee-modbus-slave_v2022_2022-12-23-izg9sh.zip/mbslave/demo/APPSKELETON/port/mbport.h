/* 
 * MODBUS Library: WIN32 port
 * Copyright (c) 2008 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: mbport.h,v 1.1 2009-01-06 13:51:32 cwalter Exp $
 */

#ifndef _MB_PORT_H
#define _MB_PORT_H

#include "stdafx.h"
#include <assert.h>

#ifdef __cplusplus
extern          "C" {
#endif

/* ----------------------- Defines ------------------------------------------*/

typedef enum
{
    MB_LOG_DEBUG,
    MB_LOG_INFO,
    MB_LOG_WARN,
    MB_LOG_ERROR
} eMBPortLogLevel;

#define INLINE                              
#define STATIC                              static

#define PR_BEGIN_EXTERN_C                   extern "C" {
#define	PR_END_EXTERN_C                     }

#define MBP_ASSERT( x )                     assert( x )

#define MBP_ENTER_CRITICAL_SECTION( )       vMBPEnterCritical( )
#define MBP_EXIT_CRITICAL_SECTION( )        vMBPExitCritical( )
#define MBP_ENTER_CRITICAL_INIT( )          vMBPEnterCriticalInit( )
#define MBP_EXIT_CRITICAL_INIT( )           vMBPExitCriticalInit( )

#ifndef TRUE
#define TRUE                                ( BOOL )1
#endif

#ifndef FALSE
#define FALSE                               ( BOOL )0
#endif

#define MBP_EVENTHDL_INVALID                NULL
#define MBP_TIMERHDL_INVALID                NULL
#define MBP_SERIALHDL_INVALID               NULL
#define MBP_TCPHDL_INVALID                  NULL
#define MBP_TCPHDL_CLIENT_INVALID           NULL

/* ----------------------- Function prototypes ------------------------------*/


/* ----------------------- Type definitions ---------------------------------*/
typedef void      *xMBPEventHandle;
typedef void      *xMBPTimerHandle;
typedef void      *xMBPSerialHandle;
typedef void      *xMBPTCPHandle;
typedef void      *xMBPTCPClientHandle;

typedef int       BOOL;
typedef unsigned char BYTE;
typedef unsigned char UBYTE;

typedef unsigned char UCHAR;
typedef char      CHAR;

typedef unsigned short USHORT;
typedef short     SHORT;

typedef unsigned long ULONG;
typedef long      LONG;

/* ----------------------- Function prototypes ------------------------------*/
void              vMBPOtherDLLInit( void );
void              vMBPOtherDLLClose( void );
void              vMBPEnterCritical( void );
void              vMBPExitCritical( void );
void              vMBPEnterCriticalInit( void );
void              vMBPExitCriticalInit( void );
void              vMBPAssert( void );
void		      vMBPPortLog( eMBPortLogLevel eLevel, const TCHAR * szModule, const TCHAR * szFmt, ... );
LPTSTR			  Error2String( DWORD dwError );


#ifdef __cplusplus
}
#endif

#endif

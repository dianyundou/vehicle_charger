/* 
 * MODBUS Slave Library: Configuration
 * Copyright (c) 2008 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: mbsconfig.h,v 1.1 2009-01-06 13:51:32 cwalter Exp $
 */

#ifndef _MBSCONFIG_H
#define _MBSCONFIG_H

#ifdef __cplusplus
PR_BEGIN_EXTERN_C
#endif

/* ----------------------- Defines ------------------------------------------*/
#define MBS_DEFAULT_RESPONSE_TIMEOUT            ( 500 )
#define MBS_ASCII_ENABLED                       ( 1 )
#define MBS_RTU_ENABLED                         ( 1 )
#define MBS_TCP_ENABLED                         ( 1 )
#define MBS_TCP_MAX_INSTANCES                   ( 2 )
#define MBS_SERIAL_API_VERSION                  ( 2 )
#define MBS_ASCII_BACKOF_TIME_MS                ( 0 ) 
#define MBS_NCUSTOM_FUNCTION_HANDLERS           ( 8 )
#define MBS_SERIAL_APIV2_RTU_TIMEOUT_MS         ( 10 )
#define MBP_ADVA_STARTUP_SHUTDOWN_ENABLED       ( 1 )
#define MBS_ASCII_WAITAFTERSEND_ENABLED         ( 0 )
#define MBS_RTU_WAITAFTERSEND_ENABLED           ( 0 )

#ifdef __cplusplus
PR_END_EXTERN_C
#endif

#endif

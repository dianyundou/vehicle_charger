/* 
 * MODBUS Library: Win32 port
 * Copyright (c) 2008 Christian Walter <wolti@sil.at>
 * All rights reserved.
 *
 * $Id: mbportserial.c,v 1.1 2009-01-06 13:51:32 cwalter Exp $
 */

/* ----------------------- System includes ----------------------------------*/
#include <stdlib.h>
#include <crtdbg.h>
/* ----------------------- Platform includes --------------------------------*/
#include "mbport.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "common/mbtypes.h"
#include "common/mbportlayer.h"
#include "common/mbframe.h"
#include "common/mbutils.h"

/* ----------------------- Defines ------------------------------------------*/
#define IDX_INVALID                     ( 255 )
#define UART_BAUDRATE_MIN               ( 300 )
#define UART_BAUDRATE_MAX               ( 115200 )
#define SER_MAX_INSTANCES               ( 8 )
#define SER_BUFFER_SIZE                 ( 32 )
#define SER_DEBUG                       ( 0 )
#define SER_TIMEOUT                     ( 5UL )
#define THREAD_STACKSIZE_MAX            ( 16384 )

#define HDL_RESET( x ) do { \
    ( x )->ubIdx = IDX_INVALID; \
    ( x )->xSerHdl = INVALID_HANDLE_VALUE; \
    ( x )->pbMBPTransmitterEmptyFN = NULL; \
    ( x )->pvMBPReceiveFN = NULL; \
    ( x )->xMBMHdl = MB_HDL_INVALID; \
    ( x )->bIsRunning = FALSE; \
} while( 0 );

#define HDL_RESET_FULL( x ) do { \
    HDL_RESET( x ); \
    ( x )->xThreadHdl = NULL; \
} while( 0 );

/* ----------------------- Type definitions ---------------------------------*/
typedef struct
{
    UBYTE           ubIdx;
    HANDLE          xSerHdl;
    HANDLE          xThreadHdl;
    pbMBPSerialTransmitterEmptyAPIV2CB pbMBPTransmitterEmptyFN;
    pvMBPSerialReceiverAPIV2CB pvMBPReceiveFN;
    BOOL            bIsRunning;
    xMBHandle       xMBMHdl;
} xSerialHandle;

/* ----------------------- Static variables ---------------------------------*/
STATIC xSerialHandle xSerialHdls[SER_MAX_INSTANCES];
STATIC BOOL     bIsInitalized = FALSE;

/* ----------------------- Static functions ---------------------------------*/
STATIC DWORD WINAPI prrvSerHandlerThread( LPVOID lpParameter );
STATIC BOOL     xMBPSerialSetTimeout( HANDLE xSerialHandle, ULONG ulBaudRate );

/* ----------------------- Start implementation -----------------------------*/

eMBErrorCode
eMBPSerialInit( xMBPSerialHandle * pxSerialHdl, UCHAR ucPort, ULONG ulBaudRate,
                UCHAR ucDataBits, eMBSerialParity eParity, UCHAR ucStopBits, xMBHandle xMBMHdl )
{
    eMBErrorCode    eStatus = MB_ENOERR;
    TCHAR           szDevice[8];
    DCB             dcb;
    UBYTE           ubIdx;
    xSerialHandle  *pxSerHdl = NULL;
    DWORD           dwThreadId;

    MBP_ENTER_CRITICAL_SECTION(  );
    if( !bIsInitalized )
    {
        for( ubIdx = 0; ubIdx < MB_UTILS_NARRSIZE( xSerialHdls ); ubIdx++ )
        {
            HDL_RESET_FULL( &xSerialHdls[ubIdx] );
        }
        bIsInitalized = TRUE;
    }

    for( ubIdx = 0; ubIdx < MB_UTILS_NARRSIZE( xSerialHdls ); ubIdx++ )
    {
        if( IDX_INVALID == xSerialHdls[ubIdx].ubIdx )
        {
            pxSerHdl = &( xSerialHdls[ubIdx] );
            /* Cleanup old unused thread data. */
            if( NULL != pxSerHdl->xThreadHdl )
            {
                ( void )CloseHandle( pxSerHdl->xThreadHdl );
                pxSerHdl->xThreadHdl = NULL;
            }
            HDL_RESET_FULL( pxSerHdl );
            pxSerHdl->ubIdx = ubIdx;
            break;
        }
    }

    if( NULL != pxSerHdl )
    {
        memset( &dcb, 0, sizeof( dcb ) );
        dcb.DCBlength = sizeof( dcb );
        dcb.BaudRate = ulBaudRate;
        _stprintf_s( szDevice, 8, _T( "COM%d" ), ucPort );

        switch ( eParity )
        {
        case MB_PAR_NONE:
            dcb.Parity = NOPARITY;
            dcb.fParity = 0;
            break;
        case MB_PAR_EVEN:
            dcb.Parity = EVENPARITY;
            dcb.fParity = 1;
            break;
        case MB_PAR_ODD:
            dcb.Parity = ODDPARITY;
            dcb.fParity = 1;
            break;
        default:
            eStatus = MB_EINVAL;
        }
        switch ( ucDataBits )
        {
        case 8:
            dcb.ByteSize = 8;
            break;
        case 7:
            dcb.ByteSize = 7;
            break;
        default:
            eStatus = MB_EINVAL;
        }
        switch ( ucStopBits )
        {
        case 1:
            dcb.StopBits = ONESTOPBIT;
            break;
        case 2:
            dcb.StopBits = TWOSTOPBITS;
            break;
        default:
            eStatus = MB_EINVAL;
        }

        if( MB_ENOERR == eStatus )
        {
            /* Initialize the data structure. */
            pxSerHdl->xMBMHdl = xMBMHdl;
            pxSerHdl->bIsRunning = TRUE;

            /* we don't use XON/XOFF flow control. */
            dcb.fInX = dcb.fOutX = FALSE;
            /* we don't need hardware handshake. */
            dcb.fOutxCtsFlow = dcb.fOutxCtsFlow = FALSE;
            dcb.fRtsControl = RTS_CONTROL_DISABLE;
            dcb.fDtrControl = DTR_CONTROL_DISABLE;

            /* misc parameters */
            dcb.fErrorChar = FALSE;
            dcb.fBinary = TRUE;
            dcb.fNull = FALSE;
            dcb.fAbortOnError = FALSE;
            dcb.wReserved = 0;
            dcb.XonLim = 2;
            dcb.XoffLim = 4;
            dcb.XonChar = 0x13;
            dcb.XoffChar = 0x19;
            dcb.EvtChar = 0;

            /* Open the serial device. */
            pxSerHdl->xSerHdl = CreateFile( szDevice, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL );

            if( INVALID_HANDLE_VALUE == pxSerHdl->xSerHdl )
            {
                vMBPPortLog( MB_LOG_ERROR, _T( "SERIAL" ), _T( "Can't open serial port %s: %s" ), szDevice,
                             Error2String( GetLastError(  ) ) );
                eStatus = MB_EPORTERR;
            }
            else if( !xMBPSerialSetTimeout( pxSerHdl->xSerHdl, ulBaudRate ) )
            {
                vMBPPortLog( MB_LOG_ERROR, _T( "SERIAL" ), _T( "Can't set timeouts for serial device: %s" ),
                             Error2String( GetLastError(  ) ) );
                eStatus = MB_EPORTERR;
            }
            else if( !SetCommState( pxSerHdl->xSerHdl, &dcb ) )
            {
                vMBPPortLog( MB_LOG_ERROR, _T( "SERIAL" ), _T( "Can't set settings for serial device %s: %s" ),
                             szDevice, Error2String( GetLastError(  ) ) );
                eStatus = MB_EPORTERR;
            }
            else if( !SetCommMask( pxSerHdl->xSerHdl, 0 ) )
            {
                vMBPPortLog( MB_LOG_ERROR, _T( "SERIAL" ),
                             _T( "Can't set communication event mask for serial device %s: %s" ), szDevice,
                             Error2String( GetLastError(  ) ) );
                eStatus = MB_EPORTERR;
            }
            else if( NULL ==
                     ( pxSerHdl->xThreadHdl =
                       CreateThread( NULL, THREAD_STACKSIZE_MAX, prrvSerHandlerThread, pxSerHdl, 0, &dwThreadId ) ) )
            {
                vMBPPortLog( MB_LOG_ERROR, _T( "SERIAL" ), _T( "Can't create handler thread: %s" ),
                             Error2String( GetLastError(  ) ) );
                eStatus = MB_EPORTERR;
            }
            else
            {
                *pxSerialHdl = pxSerHdl;
                eStatus = MB_ENOERR;
            }

            if( MB_ENOERR != eStatus )
            {
                /* No thread must have been started in the error case. */
                MBP_ASSERT( NULL == pxSerHdl->xThreadHdl );
                if( INVALID_HANDLE_VALUE != pxSerHdl->xSerHdl )
                {
                    ( void )CloseHandle( pxSerHdl->xSerHdl );
                }
                HDL_RESET_FULL( pxSerHdl );
            }
        }
    }
    else
    {
        eStatus = MB_ENORES;
    }
    MBP_EXIT_CRITICAL_SECTION(  );
    return eStatus;
}

STATIC          BOOL
xMBPSerialSetTimeout( HANDLE xSerialHandle, ULONG ulBaudRate )
{
    BOOL            bStatus;
    COMMTIMEOUTS    cto;

    /* Compute the maximum timeout between characters. Make sure
     * that we have correct rounding.
     */
    cto.ReadIntervalTimeout = MAXDWORD;
    cto.ReadTotalTimeoutConstant = SER_TIMEOUT;
    cto.ReadTotalTimeoutMultiplier = MAXDWORD;
    cto.WriteTotalTimeoutConstant = 0;
    cto.WriteTotalTimeoutMultiplier = 0;

    if( !SetCommTimeouts( xSerialHandle, &cto ) )
    {
        bStatus = FALSE;
    }
    else
    {
        bStatus = TRUE;
    }

    return bStatus;
}

eMBErrorCode
eMBPSerialClose( xMBPSerialHandle xSerialHdl )
{
    eMBErrorCode    eStatus = MB_EINVAL;
    xSerialHandle  *pxSerialIntHdl = xSerialHdl;

    MBP_ENTER_CRITICAL_SECTION(  );
    if( MB_IS_VALID_HDL( pxSerialIntHdl, xSerialHdls ) )
    {
        pxSerialIntHdl->bIsRunning = FALSE;
        eStatus = MB_ENOERR;
    }
    MBP_EXIT_CRITICAL_SECTION(  );
    return eStatus;
}

eMBErrorCode
eMBPSerialTxEnable( xMBPSerialHandle xSerialHdl, pbMBPSerialTransmitterEmptyCB pbMBPTransmitterEmptyFN )
{
    eMBErrorCode    eStatus = MB_EINVAL;
    xSerialHandle  *pxSerialIntHdl = xSerialHdl;

    MBP_ENTER_CRITICAL_SECTION(  );
    if( MB_IS_VALID_HDL( pxSerialIntHdl, xSerialHdls ) )
    {
        eStatus = MB_ENOERR;
        if( NULL != pbMBPTransmitterEmptyFN )
        {
            pxSerialIntHdl->pbMBPTransmitterEmptyFN = pbMBPTransmitterEmptyFN;
        }
        else
        {
            pxSerialIntHdl->pbMBPTransmitterEmptyFN = NULL;
        }
    }
    MBP_EXIT_CRITICAL_SECTION(  );
    return eStatus;
}

eMBErrorCode
eMBPSerialRxEnable( xMBPSerialHandle xSerialHdl, pvMBPSerialReceiverCB pvMBPReceiveFN )
{
    eMBErrorCode    eStatus = MB_EINVAL;
    xSerialHandle  *pxSerialIntHdl = xSerialHdl;

    MBP_ENTER_CRITICAL_SECTION(  );
    if( MB_IS_VALID_HDL( pxSerialIntHdl, xSerialHdls ) )
    {
        eStatus = MB_ENOERR;
        if( NULL != pvMBPReceiveFN )
        {
            pxSerialIntHdl->pvMBPReceiveFN = pvMBPReceiveFN;
        }
        else
        {
            pxSerialIntHdl->pvMBPReceiveFN = NULL;
        }
    }
    MBP_EXIT_CRITICAL_SECTION(  );
    return eStatus;
}

DWORD           WINAPI
prrvSerHandlerThread( LPVOID lpParameter )
{
    UBYTE           arubBuffer[SER_BUFFER_SIZE];
    xSerialHandle  *pxSerHdl = lpParameter;
    HANDLE          xSerDevHdl;
    pbMBPSerialTransmitterEmptyAPIV2CB pbMBPTransmitterEmptyFN;
    pvMBPSerialReceiverAPIV2CB pvMBPReceiveFN;
    BOOL            bIsRunning = TRUE;
    DWORD           dwBytesRead;
    DWORD           dwBytesToSend, dwBytesSent;
    USHORT          usBytesToSend;

#if SER_DEBUG == 1
    DWORD           dwReadStart, dwReadEnd;
    DWORD           dwPollOld, dwPollCur, dwPollDelta;
    DWORD           dwLastError;

    dwPollOld = GetTickCount(  );
#endif

    do
    {
#if SER_DEBUG == 1
        dwPollCur = GetTickCount(  );
        dwPollDelta = dwPollCur - dwPollOld;
        dwPollOld = dwPollCur;
#endif
        /* Make a copy of the variables since they are shared. */
        MBP_ENTER_CRITICAL_SECTION(  );
        bIsRunning = pxSerHdl->bIsRunning;
        xSerDevHdl = pxSerHdl->xSerHdl;
        pvMBPReceiveFN = pxSerHdl->pvMBPReceiveFN;
        pbMBPTransmitterEmptyFN = pxSerHdl->pbMBPTransmitterEmptyFN;
        MBP_EXIT_CRITICAL_SECTION(  );

        /* If receiver is enabled poll for data. */
        if( pvMBPReceiveFN )
        {

#if SER_DEBUG == 1
            dwReadStart = GetTickCount(  );
#endif
            /* Simply ignore failed reads because the caller will detect them
             * in any case since we will not send any reply.
             */
            if( ReadFile( xSerDevHdl, arubBuffer, SER_BUFFER_SIZE, &dwBytesRead, NULL ) )
            {
#if SER_DEBUG == 1
                dwReadEnd = GetTickCount(  );
#endif
                if( dwBytesRead > 0 )
                {
                    MBP_ENTER_CRITICAL_SECTION(  );
                    if( pxSerHdl->bIsRunning && ( NULL != pxSerHdl->pvMBPReceiveFN ) )
                    {
                        pxSerHdl->pvMBPReceiveFN( pxSerHdl->xMBMHdl, arubBuffer, ( USHORT ) dwBytesRead );
                    }
                    MBP_EXIT_CRITICAL_SECTION(  );
                }
#if SER_DEBUG == 1
                dwLastError = GetLastError(  );
                vMBPPortLog( MB_LOG_DEBUG, _T( "SERIAL" ), _T( "[%u]: ReadFile: start=%lu, end=%lu, read=%lu\r\n" ),
                             GetTickCount(  ), dwReadEnd, dwReadEnd, dwBytesRead );
#endif
            }
        }


        do
        {
            dwBytesSent = 0;
            dwBytesToSend = 0;
            MBP_ENTER_CRITICAL_SECTION(  );
            if( pxSerHdl->bIsRunning && ( NULL != pxSerHdl->pbMBPTransmitterEmptyFN ) )
            {
                if( !pxSerHdl->
                    pbMBPTransmitterEmptyFN( pxSerHdl->xMBMHdl, arubBuffer, SER_BUFFER_SIZE, &usBytesToSend ) )
                {
                    pxSerHdl->pbMBPTransmitterEmptyFN = NULL;
                    dwBytesToSend = 0;
                }
                else
                {
                    dwBytesToSend = usBytesToSend;
                }
            }
            MBP_EXIT_CRITICAL_SECTION(  );

            while( dwBytesToSend > 0 )
            {
                if( !WriteFile( xSerDevHdl, arubBuffer, dwBytesToSend, &dwBytesSent, NULL ) )
                {
                    /* I/O failed. There is nothing we can do about it. The
                     * caller will notice anyway since it will not receive
                     * any reply.
                     */
                    break;
                }
                else
                {
                    dwBytesToSend -= dwBytesSent;
                }
            }
        }
        while( dwBytesSent > 0 );

        /* Make a dummy wait if no event has happend. */
        if( ( NULL == pbMBPTransmitterEmptyFN ) && ( NULL == pvMBPReceiveFN ) )
        {
            Sleep( 1 );
        }
    }
    while( bIsRunning );

    ( void )CloseHandle( pxSerHdl->xSerHdl );
    MBP_ENTER_CRITICAL_SECTION(  );
    HDL_RESET( pxSerHdl );
    MBP_EXIT_CRITICAL_SECTION(  );

    ExitThread( 0 );
}

void
vMBPSerialDLLClose( void )
{
    BOOL            bThreadsRunning = FALSE;
    UBYTE           ubIdx;
    HANDLE          hThreadHandle;

    /* If this code is called we know that no MODBUS instances are
     * newly created (Because of the INIT lock) and that all
     * still running serial threads are going to shut down since
     * their bIsRunning flag has been set to FALSE.
     */
    do
    {
        hThreadHandle = NULL;
        MBP_ENTER_CRITICAL_SECTION(  );
        for( ubIdx = 0; ubIdx < MB_UTILS_NARRSIZE( xSerialHdls ); ubIdx++ )
        {
            if( NULL != xSerialHdls[ubIdx].xThreadHdl )
            {
                hThreadHandle = xSerialHdls[ubIdx].xThreadHdl;
                xSerialHdls[ubIdx].xThreadHdl = NULL;
                break;
            }
        }
        MBP_EXIT_CRITICAL_SECTION(  );
        if( NULL != hThreadHandle )
        {
            if( WAIT_OBJECT_0 != WaitForSingleObject( hThreadHandle, 5000 ) )
            {
                MBP_ASSERT( 0 );
            }
            ( void )CloseHandle( hThreadHandle );
        }
    }
    while( NULL != hThreadHandle );
}

/* 
 * MODBUS Library: Win32 port
 * Copyright (c) 2008 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: mbportother.c,v 1.1 2009-01-06 13:51:32 cwalter Exp $
 */

/* ----------------------- System includes ----------------------------------*/
#include "stdafx.h"

/* ----------------------- Platform includes --------------------------------*/
#include "mbport.h"

/* ----------------------- Modbus includes ----------------------------------*/

/* ----------------------- Defines ------------------------------------------*/
#define DEBUG_CONSOLE       ( 1 )
#define DEBUG_VSTUDIO       ( 1 )
#define DEBUG_TIMESTAMP     ( 1 )
/* ----------------------- Type definitions ---------------------------------*/

/* ----------------------- Static variables ---------------------------------*/

STATIC CRITICAL_SECTION xCritSection;
STATIC CRITICAL_SECTION xCritSectionInit;

/* ----------------------- Static functions ---------------------------------*/

/* ----------------------- Function prototypes ------------------------------*/
extern void     vMBPTimerDLLClose( void );
extern void     vMBPSerialDLLClose( void );
extern void     vMBPTCPDLLClose( void );
extern void     vMBPTCPDllInit( void );

/* ----------------------- Start implementation -----------------------------*/
LPTSTR
Error2String( DWORD dwError )
{
    static TCHAR    szUserBuf[512];
    static LPTSTR   szErrorMsg = _T( "internal error" );
    LPTSTR          lpMsgBuf = NULL;
    DWORD           dwLength;

    dwLength = FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER |
                              FORMAT_MESSAGE_FROM_SYSTEM,
                              NULL,
                              dwError, MAKELANGID( LANG_NEUTRAL, SUBLANG_DEFAULT ), ( LPTSTR ) & lpMsgBuf, 0, NULL );
    if( dwLength == 0 )
    {
        lpMsgBuf = _T( "internal error" );
    }

    _tcsnccpy_s( szUserBuf, sizeof( szUserBuf ) / sizeof( szUserBuf[0] ), lpMsgBuf, _tcslen( lpMsgBuf ) );
    LocalFree( lpMsgBuf );

    return szUserBuf;
}

void
vMBPPortLog( eMBPortLogLevel eLevel, const TCHAR * szModule, const TCHAR * szFmt, ... )
{
    TCHAR           szBuf[512];
    int             i = 0;
    va_list         args;

#if DEBUG_TIMESTAMP == 1
    SYSTEMTIME      xSystemTime;
#endif



    static const LPTSTR arszLevel2Str[] = { _T( "DEBUG" ), _T( "INFO" ), _T( "WARN" ), _T( "ERROR" ) };

#if DEBUG_TIMESTAMP == 1
    GetSystemTime( &xSystemTime );
    i = _sntprintf_s( &szBuf[i], sizeof( szBuf ) / sizeof( szBuf[0] ) - i, _TRUNCATE,
                      _T( "%02u:%02u:%03u: " ), xSystemTime.wMinute, xSystemTime.wSecond, xSystemTime.wMilliseconds );
#endif
    i += _sntprintf_s( &szBuf[i], sizeof( szBuf ) / sizeof( szBuf[0] ) - i, _TRUNCATE, _T( "%s: %s: " ),
                       arszLevel2Str[eLevel], szModule );

    if( i != 0 )
    {
        va_start( args, szFmt );
        i += _vsntprintf_s( &szBuf[i], sizeof( szBuf ) / sizeof( szBuf[0] ) - i, _TRUNCATE, szFmt, args );
        va_end( args );
    }

    if( i != 0 )
    {
        if( eLevel == MB_LOG_DEBUG )
        {
#if DEBUG_CONSOLE == 1
            _fputts( szBuf, stderr );
#endif
#if DEBUG_VSTUDIO == 1
            OutputDebugString( szBuf );
#endif
        }
        else
        {
            _fputts( szBuf, stderr );
        }
    }
}

void
vMBPLibraryLoad( void )
{
    vMBPTCPDllInit(  );
}

void
vMBPLibraryUnload( void )
{
    vMBPTimerDLLClose(  );
    vMBPSerialDLLClose(  );
    vMBPTCPDLLClose(  );
}

void
vMBPOtherDLLClose( void )
{
    DeleteCriticalSection( &xCritSection );
    DeleteCriticalSection( &xCritSectionInit );
}

void
vMBPOtherDLLInit( void )
{
    InitializeCriticalSection( &xCritSection );
    InitializeCriticalSection( &xCritSectionInit );
}

void
vMBPEnterCritical( void )
{
    EnterCriticalSection( &xCritSection );
}

void
vMBPExitCritical( void )
{
    LeaveCriticalSection( &xCritSection );
}

void
vMBPEnterCriticalInit( void )
{
    EnterCriticalSection( &xCritSectionInit );
}

void
vMBPExitCriticalInit( void )
{
    LeaveCriticalSection( &xCritSectionInit );
}

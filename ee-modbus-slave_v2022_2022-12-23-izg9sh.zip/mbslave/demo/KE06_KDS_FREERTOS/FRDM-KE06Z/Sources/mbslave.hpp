/*
 * MODBUS Library: KL06 KDS/PE/FreeRTOS port
 * Copyright (c)  2019 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 */

#ifndef MBSLAVE_H_
#define MBSLAVE_H_

#include <cstdint>
#include <vector>
#include <bitset>

#include "mbcommon.hpp"

namespace sila
{

class mbslave
{
private:
	bool m_port_initialized;
	std::vector<uint16_t> _m_buffer;

protected:
	void *m_hdl;
	mbslave( );

public:
	/* \brief This function is called by the MODBUS slave stack whenever the master reads discrete coils
	 *
	 * The implementation shall fill the bitfield coils with its  application dependent values. Exactly the
	 * number of coils have to be written. If the request can not be full-filled the function shall return
	 * an error code not equal to MB_PDU_EX_NONE. This error code is then mapped to an appropriate MODBUS
	 * exception.
	 * The function shall not block for a long time (a few milliseconds)
	 *
	 * \param coils A caller allocated bitfield which can hold up to ncoils bit
	 * \param address The address the master has requested (PDU addressing starting at 0)
	 * \param ncoils The number of coils requested
	 */
	virtual mbcommon::exceptions get_coils( mbcommon::bitfield &coils, uint16_t address, uint16_t ncoils );

	/* \brief This function is called by the MODBUS slave stack when a master writes discrete coils.
	 *
	 * The implementation shall read from the bitfield and update the application dependent values. If the
	 * request can not be full-filled the function shall return an error code not equal to MB_PDU_EX_NONE.
	 * This error code is then mapped to an appropriate MODBUS exception.
	 * The function shall not block for a long time (a few milliseconds)
	 *
	 * \param coils A bitfield which holds ncoils bit
	 * \param address The address the master has requested (PDU addressing starting at 0)
	 * \param ncoils The number of coils written by the master
	 */
	virtual mbcommon::exceptions set_coils( const mbcommon::bitfield &coils, uint16_t address, uint16_t ncoils );

	/* \brief This function is called by the MODBUS slave stack whenever the master reads discrete inputs.
	 *
	 * The implementation shall fill the bitfield discrete with its application dependent values. Exactly the
	 * number of discrete inputs have to be written. If the request can not be full-filled the function shall
	 * return an error code not equal to MB_PDU_EX_NONE. This error code is then mapped to an appropriate MODBUS
	 * exception.
	 * The function shall not block for a long time (a few milliseconds)
	 *
	 * \param discrete A bitfield which can hold up to ndiscrete bit
	 * \param address The address the master has requested (PDU addressing starting at 0)
	 * \param ndiscrete The number of discrete inputs requested
	 */
	virtual mbcommon::exceptions get_discrete( mbcommon::bitfield &discrete, uint16_t address, uint16_t ndiscrete );

	/* \brief This function is called by the MODBUS slave stack whenever the master requests input registers.
	 *
	 * The implementation shall fill the vector inputs with its application dependent values. Exactly the
	 * number of inputs have to be written. If the request can not be full-filled the function shall return
	 * an error code not equal to MB_PDU_EX_NONE. This error code is then mapped to an appropriate MODBUS
	 * exception.
	 * The function shall not block for a long time (a few milliseconds)
	 *
	 * \param inputs A caller allocated vector which can hold up to ninputs registers
	 * \param address The address the master has requested (PDU addressing starting at 0)
	 * \param ninputs The number of input registers requested
	 */
	virtual mbcommon::exceptions get_input( std::vector<uint16_t> &inputs, uint16_t address, uint16_t ninputs );

	/* \brief This function is called by the MODBUS slave stack whenever the master requests holding registers.
	 *
	 * The implementation shall fill the vector holding with its application dependent values. Exactly the
	 * number of holding registers have to be written. If the request can not be full-filled the function shall return
	 * an error code not equal to MB_PDU_EX_NONE. This error code is then mapped to an appropriate MODBUS
	 * exception.
	 * The function shall not block for a long time (a few milliseconds)
	 *
	 * \param holding A caller allocated vector which can hold up to ninputs registers
	 * \param address The address the master has requested (PDU addressing starting at 0)
	 * \param nholding The number of input registers requested
	 */
	virtual mbcommon::exceptions get_holding( std::vector<uint16_t> &holding, uint16_t address, uint16_t nholding );

	/* \brief This function is called by the MODBUS slave stack whenever the master writes holding registers.
	 *
	 * The implementation shall update its own holding registers from the values provided in the vector holding.
	 * If the request can not be full-filled the function shall return an error code not equal to MB_PDU_EX_NONE.
	 * This error code is then mapped to an appropriate MODBUS exception.
	 * The function shall not block for a long time (a few milliseconds)
	 *
	 * \param holding A caller allocated vector which can hold up to ninputs registers
	 * \param address The address the master has requested (PDU addressing starting at 0)
	 * \param nholding The number of input registers requested
	 */
	virtual mbcommon::exceptions set_holding( const std::vector<uint16_t> &holding, uint16_t address, uint16_t nholding );

	/*! \brief Callback function for custom function codes.
	 *
	 * Custom MODBUS function codes can be implemented. Whenever a master issues the request
	 * the function is called and the frame contents can be inspected within the data pdu up to
	 * length pdu_length. The function then need to populate the buffer and writes the number
	 * of bytes written into the variable pdu_length.
	 *
	 * \param pdu The MODBUS request sent by the MODBUS master which is pdu_length bytes long.
	 *  The response should be written into the same buffer and the length of the response should
	 *  be written to pdu_length. It must not exceed the size of 243 bytes.
	 * \param pdu_length Length of the MODBUS PDU request and length of the response.
	 */
	typedef mbcommon::exceptions ( *mb_handler )( class mbslave &self, uint8_t pdu[], uint8_t &pdu_length );

	/* \brief Register a custom function handler for the MODBUS code fcode.
	 *
	 */
	mbcommon::status register_custom( uint8_t fcode, mb_handler handler );

	/* \brief Polling function for the MODBUS slave. Needs to be called periodically.
	 *
	 * In case of an RTOS based implementation start the MODBUS slave in a separate thread. Create
	 * the instance in this thread and execute the poll function within a loop. In this case the
	 * lower level implementation will block on an event and no CPU ressources are spent unless needed.
	 *
	 * For an non RTOS based implementation call within your main polling loop.
	 */
	bool poll( void );

	/*! \brief Return an internal register buffer. This is used for mapping the C to C++ calls. During
	 * construction its capacity is reserved to 125 registers which is sufficient for all MODBUS API
	 * calls
	 */

	std::vector<uint16_t> &get_internal_buffer( ) { return _m_buffer; };
};

class mbrtuslave: public mbslave
{
public:
	/*!
	 * \brief Create a new instances for a serial MODBUS slave instance using
	 *   either ASCII or RTU transmission mode.
	 *
	 * The stopbits shall be decided internally by databits and operating mode. It is recommended
	 * to use the function without the stopbits argument.
	 *
	 * \param address The slave address. Only frames sent to this address
	 *   or to the broadcast address are handled. Valid slave addresses are in
	 *   the range 1 - 247.
	 * \param mode The serial transmission mode to use. Either MB_RTU or MB_ASCII.
	 * \param port The serial port to use. The meaning of this value depends on
	 *   the porting layer.
	 * \param baudrate The baudrate. For example 38400.
	 * \param parity The parity to use.
	 * \param stopbits Number of stopbits to use.
	 */
	mbrtuslave( uint8_t address, mbcommon::mode mode, uint8_t port, uint32_t baudrate, mbcommon::parity parity, uint8_t stopbits );
	mbrtuslave( uint8_t address, mbcommon::mode mode, uint8_t port, uint32_t baudrate, mbcommon::parity parity );
};

class mbtcpslave : public mbslave
{
public:
	mbtcpslave( );

	/*! \brief Create a new MODBUS TCP slave instance.
	 *
	 * This function creates a new MODBUS TCP slave listening on the
	 * address bindaddr and on port port.
	 *
	 * \param bindaddr Address to bind to. For example "0.0.0.0".
	 * \param port The TCP port to bind to. Default port should be 502.
	 */
	mbtcpslave( const char *bindaddr, uint16_t port );

};

class mbudpslave : public mbslave
{
public:
	mbudpslave( );

	/*! \brief Create a new MODBUS UDP slave instance.
	 *
	 * This function creates a new MODBUS UDP slave listening on the
	 * address bindaddr and on port port.
	 *
	 * \param bindaddr Address to bind to. For example "0.0.0.0".
	 * \param port The UDP port to bind to. Default port should be 502.
	 */
	mbudpslave( const char *bindaddr, uint16_t port );
};

}

#endif /* MBSLAVE_H_ */

/*
 * MODBUS Library: KL06 KDS/PE/FreeRTOS port
 * Copyright (c)  2019 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 */

#include <exception>
#include <stdexcept>
#include <vector>
#include <iterator>

#include "mbslave.hpp"
#include "mbport.h"
#include "mbs.h"
#include "common/mbutils.h"

using namespace sila;

mbslave::mbslave( )
{
	if( !m_port_initialized )
	{
		vMBPInit(  );
		m_port_initialized = true;
	}
	/* 125 registers is the absolute maximum which can be read/written at once */
	_m_buffer.resize( 125 );
}

bool mbslave::poll( void )
{
	bool okay = false;
	if( NULL != m_hdl )
	{
		if( MB_ENOERR == eMBSPoll( m_hdl ) )
		{
			okay = true;
		}
	}
	return okay;
}

extern "C" eMBException
mbslave_holding_cb( void *ctx, UBYTE * regbuf, USHORT address,  USHORT nregs, eMBSRegisterMode mode )
{
	eMBException status = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
	mbslave *slave = reinterpret_cast< mbslave * >( ctx );
	std::vector< uint16_t > &buffer( slave->get_internal_buffer( ) );

	if( MBS_REGISTER_READ == mode )
	{
		status = ( eMBException )slave->get_holding( buffer, address, nregs );
		if( MB_PDU_EX_NONE == status )
		{
			for( unsigned cnt = 0; cnt < nregs; cnt++ )
			{
                *regbuf++ = ( UBYTE ) ( buffer[cnt] >> 8 );
                *regbuf++ = ( UBYTE ) ( buffer[cnt] & 0xFF );
			}
		}
	}
	else
	{
        for( unsigned cnt = 0; cnt <= nregs; cnt++ )
        {
        	buffer[cnt] = ( USHORT ) * regbuf++ << 8;
        	buffer[cnt] |= ( USHORT ) * regbuf++;
        }
        status = ( eMBException )slave->set_holding( buffer, address, nregs );
	}
	return status;
}

extern "C" eMBException
mbslave_input_cb( void *ctx, UBYTE * regbuf, USHORT address,  USHORT nregs )
{
	eMBException status = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
	mbslave *slave = reinterpret_cast< mbslave * >( ctx );
	std::vector< uint16_t > &buffer( slave->get_internal_buffer( ) );

	status = ( eMBException )slave->get_input( buffer, address, nregs );
	if( MB_PDU_EX_NONE == status )
	{
		for( unsigned cnt = 0; cnt < nregs; cnt++ )
		{
			*regbuf++ = ( UBYTE ) ( buffer[cnt] >> 8 );
			*regbuf++ = ( UBYTE ) ( buffer[cnt] & 0xFF );
		}
	}
	return status;
}

mbrtuslave::mbrtuslave( uint8_t address, mbcommon::mode mode, uint8_t port, uint32_t baudrate, mbcommon::parity parity, uint8_t stopbits )
{

	eMBErrorCode eStatus = eMBSSerialInitExt( &m_hdl, (eMBSerialMode)mode, address, port, baudrate, (eMBSerialParity)parity, stopbits, this );
	if( MB_ENOERR != eStatus )
	{
		throw std::runtime_error( "MODBUS RTU init failed" );
	}
	else
	{
		if( MB_ENOERR != ( eStatus = eMBSRegisterHoldingCB( m_hdl, mbslave_holding_cb ) ) )
		{
			( void )eMBSClose( m_hdl );
			throw std::runtime_error( "MODBUS RTU init failed" );
		}
		if( MB_ENOERR != ( eStatus = eMBSRegisterInputCB( m_hdl, mbslave_input_cb ) ) )
		{
			( void )eMBSClose( m_hdl );
			throw std::runtime_error( "MODBUS RTU init failed" );
		}
	}
}

mbrtuslave::mbrtuslave( uint8_t address, mbcommon::mode mode, uint8_t port, uint32_t baudrate, mbcommon::parity parity ) :
	mbrtuslave( address, mode, port, baudrate, parity, parity == mbcommon::MB_PAR_NONE ? 2 : 1 )
{

}

mbcommon::exceptions mbslave::get_coils( mbcommon::bitfield &coils, uint16_t address, uint16_t ncoils )
{
	return mbcommon::MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
}

mbcommon::exceptions mbslave::set_coils( const mbcommon::bitfield &coils, uint16_t address, uint16_t ncoils )
{
	return mbcommon::MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
}

mbcommon::exceptions mbslave::get_discrete( mbcommon::bitfield &discrete, uint16_t address, uint16_t ndiscrete )
{
	return mbcommon::MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
}

mbcommon::exceptions mbslave::get_input( std::vector<uint16_t> &inputs, uint16_t address, uint16_t ninputs )
{
	return mbcommon::MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
}

mbcommon::exceptions mbslave::get_holding( std::vector<uint16_t> &holding, uint16_t address, uint16_t nholding )
{
	return mbcommon::MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
}

mbcommon::exceptions mbslave::set_holding( const std::vector<uint16_t> &holding, uint16_t address, uint16_t nholding )
{
	return mbcommon::MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
}

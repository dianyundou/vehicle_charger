/*
 * MODBUS Library: KL06 KDS/PE/FreeRTOS port
 * Copyright (c)  2019 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 */

#include <cmath>
#include <cstdlib>

#include "mbslave.hpp"
#include "freertos.h"
#include "task.h"

using namespace sila;

class mymbslave : public mbrtuslave
{
private:
	std::vector<uint16_t> m_holding_regs;
	const uint16_t m_holding_regs_start = 0;
	std::vector<uint16_t> m_input_regs;
	const uint16_t m_input_regs_start = 10;

public:
	mymbslave( uint8_t address, mbcommon::mode mode, uint8_t port, uint32_t baudrate, mbcommon::parity parity ) :
		mbrtuslave( address, mode, port, baudrate, parity )
	{
		m_holding_regs.resize( 20 );
		m_holding_regs[17] = 0x1234;

		m_input_regs.resize( 10 );
		for( std::vector<uint16_t>::iterator i = m_input_regs.begin( ); i != m_input_regs.end( ); i++ )
		{
			*i = std::rand( );
		}
	}

	 mbcommon::exceptions get_input( std::vector<uint16_t> &input, uint16_t address, uint16_t ninput )
	 {
		 mbcommon::exceptions exception = mbcommon::MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
		 if( ( address >= m_input_regs_start ) &&
		     ( ( address + ninput ) <= ( m_input_regs_start + m_input_regs.size( ) ) ) )
		 {
			 unsigned offset = address - m_input_regs_start;
			 for( unsigned cnt = 0; cnt < ninput; cnt++ )
			 {
				 input[cnt] = m_input_regs[cnt+offset];
			 }
			 exception = mbcommon::MB_PDU_EX_NONE;
		 }
		 return exception;
	 }

	 mbcommon::exceptions get_holding( std::vector<uint16_t> &holding, uint16_t address, uint16_t nholding )
	 {
		 mbcommon::exceptions exception = mbcommon::MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
		 if( ( address >= m_holding_regs_start ) &&
		     ( ( address + nholding ) <= ( m_holding_regs_start + m_holding_regs.size( ) ) ) )
		 {
			 unsigned offset = address - m_holding_regs_start;
			 for( unsigned cnt = 0; cnt < nholding; cnt++ )
			 {
				 holding[cnt] = m_holding_regs[cnt+offset];
			 }
			 exception = mbcommon::MB_PDU_EX_NONE;
		 }
		 return exception;
	 }

	 mbcommon::exceptions set_holding( const std::vector<uint16_t> &holding, uint16_t address, uint16_t nholding )
	 {
		 mbcommon::exceptions exception = mbcommon::MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
		 static uint16_t debug_val;
		 if( ( address >= m_holding_regs_start ) &&
		     ( ( address + nholding ) <= ( m_holding_regs_start + m_holding_regs.size( ) ) ) )
		 {
			 unsigned offset = address - m_holding_regs_start;
			 for( unsigned cnt = 0; cnt < nholding; cnt++ )
			 {
				 debug_val = holding[cnt];
				 m_holding_regs[cnt+offset] = debug_val;
			 }
			 exception = mbcommon::MB_PDU_EX_NONE;
		 }
		 return exception;
	 }
};

extern "C" void
AppTask(void *pvParameters)
{
	mymbslave slave( 1, mbcommon::MB_RTU,  0, 38400, mbcommon::MB_PAR_ODD );
	for( ;; )
	{
		slave.poll( );
	}
}

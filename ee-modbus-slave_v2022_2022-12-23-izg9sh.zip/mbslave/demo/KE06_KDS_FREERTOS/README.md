# Description

* SOC: MKE06Z128VLK4
* EvalBoard: NXP FRDM-KE06Z
* Kinetis Design Studio 3.X / FreeRTOS
* PE UART
* RTU / RS485 @ 38400 odd / Slave address : 1

| Registers | Start  | Length |
|:---------:|:------:|:------:|
| Input     | 0x0000 | 32     |
| Holding   | 0x0000 | 32     |


# Notes

* On startup a new thread <AppTask> defined in modbus.cpp is started.
It creates a new instance of a subclass of mbrtuslave. The subclass
implements the appropriate register callbacks which are called whenever
a MODBUS master reads or writes a specific set of registers. The 
default implementation return an exception.
* For adapting to a specific platform the following steps have to be
taken : 

  * mbportserial.c: If required add direction pin control for the RS485
 driver enable pin. The demo already contains this and the pin is 
 mapped to PTE5.
  * mbportserial.c: The function <eMBPSerialInit> uses the port argument
 to initialize the appropriate serial device. 

# History
* 2019-07-14: Created
* 2019-12-29:  
     - Fixed bug with 7 databits
     - Fixed bug with return value in timer callback missing
     - Fixed missing return value in poll
     - Update PE Components to Components 

# Status

| Project | Compile | Linking | Tested on Target |
| --------|:-------:|:-------:|:----------------:|
| OK      |     OK  |   OK    |  2019-07-14      |
/* 
 * MODBUS Slave Library: Application skeletion
 * Copyright (c) 2008 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: mbsdemo-ser.c,v 1.1 2008-04-06 07:47:26 cwalter Exp $
 */

/* ----------------------- System includes ----------------------------------*/

/* ----------------------- Platform includes --------------------------------*/
#include "mbport.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "mbs.h"
#include "common/mbtypes.h"
#include "common/mbutils.h"
#include "common/mbportlayer.h"

/* ----------------------- Defines ------------------------------------------*/

#define MBS_SERIAL_PORT             ( 0 )
#define MBS_SERIAL_BAUDRATE         ( 19200 )
#define MBS_PARITY                  ( MB_PAR_NONE )
#define MBS_SLAVE_ADDRESS           ( 1 )

#define REG_HOLDING_POWER_OUT       ( 0 )
#define REG_HOLDING_VALVE_1         ( 1 )
#define REG_HOLDING_VALVE_2         ( 2 )

/* ----------------------- Type definitions ---------------------------------*/

/* ----------------------- Static variables ---------------------------------*/

STATIC USHORT   usRegInputValue[16];
STATIC USHORT   usRegHoldingValue[3];

/* ----------------------- Static functions ---------------------------------*/
STATIC eMBException eMyRegInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs );
STATIC eMBException eMyRegHoldingCB( UBYTE * pubRegBuffer, USHORT usAddress,
                                     USHORT usNRegs, eMBSRegisterMode eRegMode );
STATIC eMBException eMyDiscInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs );

/* ----------------------- Start implementation -----------------------------*/
int
main( void )
{
    eMBErrorCode    eStatus;

    xMBSHandle      xMBSHdl;

    do
    {
        if( MB_ENOERR !=
            ( eStatus =
              eMBSSerialInit( &xMBSHdl, MB_RTU, MBS_SLAVE_ADDRESS,
                              MBS_SERIAL_PORT, MBS_SERIAL_BAUDRATE, MBS_PARITY ) ) )
        {
        }
        else if( MB_ENOERR != ( eStatus = eMBSRegisterInputCB( xMBSHdl, eMyRegInputCB ) ) )
        {
            ( void )eMBSClose( xMBSHdl );
        }
        else if( MB_ENOERR != ( eStatus = eMBSRegisterHoldingCB( xMBSHdl, eMyRegHoldingCB ) ) )
        {
            ( void )eMBSClose( xMBSHdl );
        }
        else if( MB_ENOERR != ( eStatus = eMBSRegisterDiscreteCB( xMBSHdl, eMyDiscInputCB ) ) )
        {
            ( void )eMBSClose( xMBSHdl );
        }
        else
        {
            do
            {
                /* Poll the communication stack. */
                eMBSPoll( xMBSHdl );
            }
            while( MB_ENOERR == eStatus );
            ( void )eMBSClose( xMBSHdl );
        }
    }
    while( TRUE );
}

eMBException
eMyRegInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs )
{
    eMBException    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
    STATIC const ULONG usRegsMappedAt = 0x0100;
    ULONG           usRegStart = usAddress;
    ULONG           usRegEnd = usAddress + usNRegs - 1;
    USHORT          usIndex;
    USHORT          usIndexEnd;

    if( ( usNRegs > 0 ) &&
        ( usRegStart >= usRegsMappedAt ) && ( usRegEnd <= ( usRegsMappedAt + MB_UTILS_NARRSIZE( usRegInputValue ) ) ) )
    {
        usIndex = ( USHORT ) ( usRegStart - usRegsMappedAt );
        usIndexEnd = ( USHORT ) ( usRegEnd - usRegsMappedAt );
        for( ; usIndex <= usIndexEnd; usIndex++ )
        {
            *pubRegBuffer++ = ( UBYTE ) ( usRegInputValue[usIndex] >> 8 );
            *pubRegBuffer++ = ( UBYTE ) ( usRegInputValue[usIndex] & 0xFF );
        }
        eException = MB_PDU_EX_NONE;
    }
    return eException;
}

eMBException
eMyRegHoldingCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs, eMBSRegisterMode eRegMode )
{
    eMBException    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
    STATIC const ULONG usRegsMappedAt = 0x0200;
    ULONG           usRegStart = usAddress;
    ULONG           usRegEnd = usAddress + usNRegs - 1;
    USHORT          usIndex;
    USHORT          usIndexEnd;

    if( ( usNRegs > 0 ) &&
        ( usRegStart >= usRegsMappedAt )
        && ( usRegEnd <= ( usRegsMappedAt + MB_UTILS_NARRSIZE( usRegHoldingValue ) ) ) )
    {
        usIndex = ( USHORT ) ( usRegStart - usRegsMappedAt );
        usIndexEnd = ( USHORT ) ( usRegEnd - usRegsMappedAt );
        switch ( eRegMode )
        {
        case MBS_REGISTER_WRITE:
            for( ; usIndex <= usIndexEnd; usIndex++ )
            {
                usRegHoldingValue[usIndex] = ( USHORT ) * pubRegBuffer++ << 8;
                usRegHoldingValue[usIndex] |= ( USHORT ) * pubRegBuffer++;
            }
            break;

        default:
        case MBS_REGISTER_READ:

            for( ; usIndex <= usIndexEnd; usIndex++ )
            {
                *pubRegBuffer++ = ( UBYTE ) ( usRegHoldingValue[usIndex] >> 8 );
                *pubRegBuffer++ = ( UBYTE ) ( usRegHoldingValue[usIndex] & 0xFF );
            }
            break;
        }
        eException = MB_PDU_EX_NONE;
    }
    return eException;
}

eMBException
eMyDiscInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs )
{
    eMBException    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
    STATIC const ULONG usRegsMappedAt = 0x0100;
    ULONG           usRegStart = usAddress;
    ULONG           usRegEnd = usAddress + usNRegs - 1;
    USHORT          usIndex;
    USHORT          usIndexEnd;

    if( ( usNRegs > 0 ) &&
        ( usRegStart >= usRegsMappedAt ) && ( usRegEnd <= ( usRegsMappedAt + MB_UTILS_NARRSIZE( usRegInputValue ) ) ) )
    {
        usIndex = ( USHORT ) ( usRegStart - usRegsMappedAt );
        usIndexEnd = ( USHORT ) ( usRegEnd - usRegsMappedAt );
        for( ; usIndex <= usIndexEnd; usIndex++ )
        {
            *pubRegBuffer++ = ( UBYTE ) ( usRegInputValue[usIndex] >> 8 );
            *pubRegBuffer++ = ( UBYTE ) ( usRegInputValue[usIndex] & 0xFF );
        }
        eException = MB_PDU_EX_NONE;
    }
    return eException;
}


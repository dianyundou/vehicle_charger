/* 
 * MODBUS Library: ATxmega port
 * Copyright (c) 2014 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: mbsconfig.h,v 1.1 2014-03-09 12:33:52 embedded-so.embedded-solutions.1 Exp $
 */

#ifndef _MBS_CONFIG_H
#define _MBS_CONFIG_H

#ifdef __cplusplus
PR_BEGIN_EXTERN_C
#endif

/* ----------------------- Defines ------------------------------------------*/
#define MBS_ASCII_ENABLED                       ( 0 )
#define MBS_RTU_ENABLED                         ( 1 )
#define MBS_TCP_ENABLED                         ( 0 )
#define MBS_SERIAL_RTU_MAX_INSTANCES            ( 1 )
#define MBS_SERIAL_ASCII_MAX_INSTANCES          ( 0 )
#define MBS_TCP_MAX_INSTANCES                   ( 0 )
#define MBS_SERIAL_API_VERSION                  ( 1 )
#define MBS_SERIAL_DROPFRAME_TIMEOUT_CB			( 1 )

#ifdef __cplusplus
PR_END_EXTERN_C
#endif

#endif

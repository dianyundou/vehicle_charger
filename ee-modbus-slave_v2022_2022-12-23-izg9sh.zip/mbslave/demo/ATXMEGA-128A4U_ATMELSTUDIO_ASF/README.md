# Description

* SOC: ATXMEGA-128A4U
* EvalBoard: n/a
* Atmel Studio 7.0 / AFS
* USARTC0 and PORTC 2/3
* RTU / MODBUS @ 19200 NONE / Slave address : 1

| Registers | Start  | Length |
|:---------:|:------:|:------:|
| Input     | 0x0000 | 16     |
| Holding   | 0x0000 | 16     |


# Notes

Holding register 0x0000 will be reset to 0 if written, others keep their values.
Input registers 0x0000 contains 0x4545, others will contain 0x0000.

# History
* 2014-03-09: Created
* 2020-03-24: Updated to Atmel Studio 7.0

# Status

| Project | Compile | Linking | Tested on Target |
| --------|:-------:|:-------:|:----------------:|
| OK      |     OK  |   OK    |  2014-03-09      |
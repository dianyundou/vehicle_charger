# Description

* SOC: AVR_ATmega2561
* EvalBoard: n/a
* Atmel Studio 7.0
* USART on PORTA
* RTU / MODBUS @ 19200 NONE / Slave address : 1

| Registers | Start  | Length |
|:---------:|:------:|:------:|
| Input     | 0x0100 | 16     |
| Holding   | 0x0200 | 3      |
| Discrete  | 0x0100 | 16     |


# Notes

Discrete and Input registers are mirrored.
Led 0 is turned on/off when holding register 1 has a value > 0.

# History
* 2020-04-23: Created

# Status

| Project | Compile | Linking | Tested on Target |
| --------|:-------:|:-------:|:----------------:|
| OK      |     OK  |   OK    |  2020-04-23      |
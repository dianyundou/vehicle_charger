/* 
 * MODBUS Slave Library: AVR demo application
 * Copyright (c) 2007 Christian Walter <wolti@sil.at>
 * All rights reserved.
 *
 * $Id: demo-discrete.c,v 1.1 2007-11-21 15:55:39 cwalter Exp $
 */

/* ----------------------- System includes ----------------------------------*/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

/* ----------------------- Platform includes --------------------------------*/
#include "mbport.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "mbs.h"
#include "common/mbtypes.h"
#include "common/mbutils.h"
#include "common/mbportlayer.h"

/* ----------------------- Defines ------------------------------------------*/

#define MBS_SERIAL_PORT			  ( 0 )
#define MBS_SERIAL_BAUDRATE		  ( 19200 )
#define MBS_PARITY				  ( MB_PAR_NONE )
#define MBS_SLAVE_ADDRESS         ( 1 )

/* ----------------------- Type definitions ---------------------------------*/

/* ----------------------- Static variables ---------------------------------*/

STATIC UBYTE    ubDiscreteInputs[2] = { 0xA5, 0x5A };

/* ----------------------- Static functions ---------------------------------*/
STATIC eMBException eMyDiscInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs );
STATIC void     vSetupRTC( void );

/* ----------------------- Start implementation -----------------------------*/
int
main( void )
{
    eMBErrorCode    eStatus;
    xMBSHandle      xMBSHdl;

    sei(  );
    do
    {
        vSetupRTC(  );
        if( MB_ENOERR !=
            ( eStatus =
              eMBSSerialInit( &xMBSHdl, MB_RTU, MBS_SLAVE_ADDRESS, MBS_SERIAL_PORT, MBS_SERIAL_BAUDRATE,
                              MBS_PARITY ) ) )
        {
        }
        else if( MB_ENOERR != ( eStatus = eMBSRegisterDiscreteCB( xMBSHdl, eMyDiscInputCB ) ) )
        {
            ( void )eMBSClose( xMBSHdl );
        }
        else
        {
            do
            {
                /* Poll the communication stack. */
                eMBSPoll( xMBSHdl );

            }
            while( MB_ENOERR == eStatus );
            ( void )eMBSClose( xMBSHdl );
        }
    }
    while( TRUE );
}

eMBException
eMyDiscInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs )
{
    eMBException    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;

    /* Our 2 byte array is mapped to 16 discrete input registers starting
     * at 100.
     */
    STATIC const ULONG usInputsStart = 100UL;
    STATIC const ULONG usInputsEnd = 115UL;
    ULONG           usAddressStart = usAddress;
    ULONG           usAddressEnd = usAddress + usNRegs - 1;

    UBYTE           usOutputBitIndex;
    UBYTE           usInputBitIndex;
    UBYTE           usInputByteIndex;

    if( ( usNRegs > 0 ) && ( usAddressStart >= usInputsStart ) && ( usAddressEnd <= usInputsEnd ) )
    {
        usOutputBitIndex = 0;
        usInputByteIndex = ( USHORT ) ( usAddressStart - usInputsStart ) / 8;
        usInputBitIndex = ( USHORT ) ( usAddressStart - usInputsStart ) % 8UL;

        *pubRegBuffer = 0;

        for( ; usAddressStart <= usAddressEnd; usAddressStart++ )
        {
            cli(  );
            if( ubDiscreteInputs[usInputByteIndex] & ( 1 << usInputBitIndex ) )
            {
                *pubRegBuffer |= ( 1 << usOutputBitIndex );
            }
            sei(  );
            usInputBitIndex++;
            if( usInputBitIndex >= 8 )
            {
                usInputByteIndex++;
                usInputBitIndex = 0;
            }

            usOutputBitIndex++;
            if( usOutputBitIndex >= 8 )
            {
                usOutputBitIndex = 0;
                pubRegBuffer++;
                *pubRegBuffer = 0;
            }
        }
        eException = MB_PDU_EX_NONE;
    }
    return eException;
}

void
vSetupRTC( void )
{
    MBP_ENTER_CRITICAL_SECTION(  );
    TCCR0A = _BV( WGM01 );
    TCCR0B = _BV( CS02 ) | _BV( CS00 );
    OCR0A = ( ( F_CPU ) / ( ( ULONG ) 1024UL * 100UL ) );       /* 10ms timer */
    TIMSK0 = _BV( OCIE0A );
    MBP_EXIT_CRITICAL_SECTION(  );
}

SIGNAL( SIG_OUTPUT_COMPARE0A )
{
    STATIC UBYTE    us1SecCounter = 0;
    UBYTE           ubHigh;

    us1SecCounter++;
    if( us1SecCounter >= 100 )
    {
        ubHigh = ubDiscreteInputs[1] & 0x80 ? 1 : 0;
        ubDiscreteInputs[1] <<= 1;
        if( ubDiscreteInputs[0] & 0x80 )
        {
            ubDiscreteInputs[1] |= 1;
        }
        ubDiscreteInputs[0] <<= 1;
        if( ubHigh )
        {
            ubDiscreteInputs[0] |= 1;
        }
        us1SecCounter = 0;
    }
}

/* 
 * MODBUS Slave Library: Linux/lwIP
 * Copyright (c) 2014 Christian Walter <cwalter@embedded-solutions.at>
 * All rights reserved.
 *
 * $Id: demo-tcp.c,v 1.1 2014-08-18 21:40:50 embedded-solutions.cwalter Exp $
 */

/* ----------------------- System includes ----------------------------------*/
#include <lwip/api.h>
#include <lwip/tcpip.h>
#include "netif/tapif.h"
#include "netif/tunif.h"
#include "netif/unixif.h"
#include "netif/dropif.h"
#include "netif/pcapif.h"

#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>

/* ----------------------- Platform includes --------------------------------*/
#include "mbport.h"

/* ----------------------- Modbus includes ----------------------------------*/
#include "mbs.h"
#include "common/mbtypes.h"
#include "common/mbutils.h"
#include "common/mbportlayer.h"

/* ----------------------- Defines ------------------------------------------*/
#define MBS_LISTEN_ADDRESS              "0.0.0.0"
#define MBS_LISTEN_PORT                 1502

/* ----------------------- Static functions ---------------------------------*/

/* ----------------------- Global variables ---------------------------------*/
unsigned char   debug_flags;

/* ----------------------- Static variables ---------------------------------*/
STATIC USHORT   usRegInputValue[16] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };

STATIC USHORT   usRegHoldingValue[15];

STATIC struct
{
    BOOL            bSlave1Okay;
    BOOL            bFinished;

#if MBS_ENABLE_STATISTICS_INTERFACE > 0
    xMBStat         xCurrentStat;

#endif                          /*  */
} xThreadData;

/* ----------------------- Static functions ---------------------------------*/
STATIC eMBException eMyRegInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs );

STATIC eMBException eMyRegHoldingCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs, eMBSRegisterMode eRegMode );

static void modbus_thread( void *arg );

/* (manual) host IP configuration */
static ip_addr_t ipaddr, netmask, gw;
static struct netif netif;


/* ----------------------- Start implementation -----------------------------*/
static void
init_netifs( void )
{
    netif_set_default( netif_add( &netif, &ipaddr, &netmask, &gw, NULL, tapif_init, tcpip_input ) );
    netif_set_up( &netif );
}


static void
tcpip_init_done( void *arg )
{
    sys_sem_t      *sem;
    sem = ( sys_sem_t * ) arg;

    init_netifs(  );

    sys_sem_signal( sem );
}

static void
main_thread( void *arg )
{
    sys_sem_t       sem;
    netif_init(  );
    if( sys_sem_new( &sem, 0 ) != ERR_OK )
    {
        LWIP_ASSERT( "Failed to create semaphore", 0 );
    }
    tcpip_init( tcpip_init_done, &sem );
    sys_sem_wait( &sem );
    printf( "TCP/IP initialized.\n" );
    sys_thread_new( "modbus_thread", modbus_thread, NULL, DEFAULT_THREAD_STACKSIZE, DEFAULT_THREAD_PRIO );
    sys_sem_wait( &sem );
}

static void
modbus_thread( void *arg )
{
    xMBHandle       xMBSHdl;
    eMBErrorCode    eStatus;
    BOOL            bIsRunning = TRUE;

    do

    {
        if( MB_ENOERR != ( eStatus = eMBSTCPInit( &xMBSHdl, MBS_LISTEN_ADDRESS, MBS_LISTEN_PORT ) ) )

        {
            printf( " %d\n", eStatus );
            fprintf( stderr, "Error: failed to startup MODBUS slave stack on %s:%hu\n", MBS_LISTEN_ADDRESS, ( USHORT ) MBS_LISTEN_PORT );
        }

        else if( MB_ENOERR != ( eStatus = eMBSRegisterInputCB( xMBSHdl, eMyRegInputCB ) ) )

        {
            ( void )eMBSClose( xMBSHdl );
        }

        else if( MB_ENOERR != ( eStatus = eMBSRegisterHoldingCB( xMBSHdl, eMyRegHoldingCB ) ) )

        {
            ( void )eMBSClose( xMBSHdl );
        }
        else
        {
            do
            {
                /* Poll the communication stack. */
                eStatus = eMBSPoll( xMBSHdl );

                /* Update a input register */
                usRegInputValue[0]++;
            }
            while( bIsRunning && ( MB_EILLSTATE != eStatus ) );
            if( MB_ENOERR != ( eStatus = eMBSClose( xMBSHdl ) ) )
            {
                MBP_ASSERT( 0 );
            }
        }

        sleep( 1 );
    }
    while( bIsRunning );
}


int
main( int argc, char *argv[] )
{
    /* startup defaults (may be overridden by one or more opts) */
    IP4_ADDR( &gw, 192, 168, 0, 1 );
    IP4_ADDR( &netmask, 255, 255, 255, 0 );
    IP4_ADDR( &ipaddr, 192, 168, 0, 2 );
    debug_flags = LWIP_DBG_OFF;

    vMBPOtherDLLInit(  );
    sys_thread_new( "main_thread", main_thread, NULL, DEFAULT_THREAD_STACKSIZE, DEFAULT_THREAD_PRIO );

    pause(  );

    vMBPOtherDLLClose(  );
    return 0;
}

eMBException
eMyRegInputCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs )
{
    eMBException    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
    STATIC const ULONG usRegsMappedAt = 0x0000;
    ULONG           usRegStart = usAddress;
    ULONG           usRegEnd = usAddress + usNRegs - 1;
    USHORT          usIndex;
    USHORT          usIndexEnd;

    if( ( usNRegs > 0 ) && ( usRegStart >= usRegsMappedAt ) && ( usRegEnd <= ( usRegsMappedAt + MB_UTILS_NARRSIZE( usRegInputValue ) ) ) )

    {
        usIndex = ( USHORT ) ( usRegStart - usRegsMappedAt );
        usIndexEnd = ( USHORT ) ( usRegEnd - usRegsMappedAt );
        for( ; usIndex <= usIndexEnd; usIndex++ )

        {
            *pubRegBuffer++ = ( UBYTE ) ( usRegInputValue[usIndex] >> 8 );
            *pubRegBuffer++ = ( UBYTE ) ( usRegInputValue[usIndex] & 0xFF );
        }
        eException = MB_PDU_EX_NONE;
    }
    return eException;
}

eMBException
eMyRegHoldingCB( UBYTE * pubRegBuffer, USHORT usAddress, USHORT usNRegs, eMBSRegisterMode eRegMode )
{
    eMBException    eException = MB_PDU_EX_ILLEGAL_DATA_ADDRESS;
    STATIC const ULONG usRegsMappedAt = 0x0000;
    ULONG           usRegStart = usAddress;
    ULONG           usRegEnd = usAddress + usNRegs - 1;
    USHORT          usIndex;
    USHORT          usIndexEnd;

    if( ( usNRegs > 0 ) && ( usRegStart >= usRegsMappedAt ) && ( usRegEnd <= ( usRegsMappedAt + MB_UTILS_NARRSIZE( usRegHoldingValue ) ) ) )

    {
        usIndex = ( USHORT ) ( usRegStart - usRegsMappedAt );
        usIndexEnd = ( USHORT ) ( usRegEnd - usRegsMappedAt );
        switch ( eRegMode )

        {
        case MBS_REGISTER_WRITE:
            for( ; usIndex <= usIndexEnd; usIndex++ )

            {
                usRegHoldingValue[usIndex] = ( USHORT ) * pubRegBuffer++ << 8;
                usRegHoldingValue[usIndex] |= ( USHORT ) * pubRegBuffer++;
            }
            break;
        default:
        case MBS_REGISTER_READ:
            for( ; usIndex <= usIndexEnd; usIndex++ )

            {
                *pubRegBuffer++ = ( UBYTE ) ( usRegHoldingValue[usIndex] >> 8 );
                *pubRegBuffer++ = ( UBYTE ) ( usRegHoldingValue[usIndex] & 0xFF );
            }
            break;
        }
        eException = MB_PDU_EX_NONE;
    }
    return eException;
}

var annotated_dup =
[
    [ "xMBAnalyzerFrame", "structxMBAnalyzerFrame.html", "structxMBAnalyzerFrame" ],
    [ "xMBCustomFunctionHandler", "structxMBCustomFunctionHandler.html", "structxMBCustomFunctionHandler" ],
    [ "xMBSInternalHandle_tag", "structxMBSInternalHandle__tag.html", "structxMBSInternalHandle__tag" ],
    [ "xMBSRegisterCB", "structxMBSRegisterCB.html", "structxMBSRegisterCB" ],
    [ "xMBStat", "structxMBStat.html", "structxMBStat" ]
];
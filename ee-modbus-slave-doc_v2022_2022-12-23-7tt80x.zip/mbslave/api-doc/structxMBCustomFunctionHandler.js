var structxMBCustomFunctionHandler =
[
    [ "peMBSFunctionCB", "structxMBCustomFunctionHandler.html#aa4199ee996f0ad1f5585cd03468448c5", null ],
    [ "ubFunctionCode", "structxMBCustomFunctionHandler.html#a7904fe52f1ffb866bb344f1f2fd16060", null ]
];
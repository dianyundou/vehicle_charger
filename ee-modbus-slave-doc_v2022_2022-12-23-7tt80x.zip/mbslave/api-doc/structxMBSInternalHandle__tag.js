var structxMBSInternalHandle__tag =
[
    [ "bIsSerialDevice", "structxMBSInternalHandle__tag.html#a4adbd9405dae5dcddd72ab64810f1714", null ],
    [ "eSlaveState", "structxMBSInternalHandle__tag.html#a6d911c829c93e534c1d4de8745c0999f", null ],
    [ "pFrameCloseFN", "structxMBSInternalHandle__tag.html#a61cc57a75b0fac68b87b2dd181e22651", null ],
    [ "pFrameRecvFN", "structxMBSInternalHandle__tag.html#a2a92b837dfd3c4b1642ec0ad3f7ad405", null ],
    [ "pFrameSendFN", "structxMBSInternalHandle__tag.html#a177ad848dd59288eabdda64ee996c883", null ],
    [ "pubFrameMBPDUBuffer", "structxMBSInternalHandle__tag.html#ad17d2896d87d9fcb9ae907f30aaf27ed", null ],
    [ "ubIdx", "structxMBSInternalHandle__tag.html#a05f70d465663a6c4a6843716550191e2", null ],
    [ "ubSlaveAddress", "structxMBSInternalHandle__tag.html#ae32436cc10813f2c80dd4a092d5a00b4", null ],
    [ "usFrameMBPDULength", "structxMBSInternalHandle__tag.html#a554d70d35aa5f5a005b1dfd9e4262ad7", null ],
    [ "xFrameEventHdl", "structxMBSInternalHandle__tag.html#ad818d99a5d5fe28fc7fc2393322a4fb2", null ],
    [ "xFrameHdl", "structxMBSInternalHandle__tag.html#a434535d0c1cc3cfeafecafc602133c22", null ],
    [ "xMBSRegCB", "structxMBSInternalHandle__tag.html#ac694132c9a068ae5a21c33667cee4ccf", null ]
];
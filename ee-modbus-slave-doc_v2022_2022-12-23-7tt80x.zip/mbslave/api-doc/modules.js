var modules =
[
    [ "MODBUS Slave", "group__mbs.html", "group__mbs" ],
    [ "MODBUS Functions", "group__mbs__functions.html", "group__mbs__functions" ],
    [ "MODBUS Common", "group__mb__cmn.html", "group__mb__cmn" ],
    [ "MODBUS Porting Layer", "group__mb__port.html", "group__mb__port" ]
];
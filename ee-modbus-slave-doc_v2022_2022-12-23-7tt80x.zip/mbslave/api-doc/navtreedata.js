/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "EE MODBUS SLAVE", "index.html", [
    [ "Requirements", "index.html#requirements", null ],
    [ "Introduction", "index.html#intro", null ],
    [ "Available ports", "index.html#ports", null ],
    [ "FAQ", "sec_faq.html", [
      [ "FAQ Entries", "sec_faq.html#FAQ", [
        [ "With V2 Serial API stack sometimes does not respond to requests", "sec_faq.html#sec_faq_design_state_machine", null ]
      ] ],
      [ "What is the best way to update registers within the software?", "sec_faq.html#sec_faq_update_reg", [
        [ "Updating of registers without an RTOS:", "sec_faq.html#sec_faq_update_reg_no_rtos", null ]
      ] ],
      [ "Updating of registers with an RTOS:", "sec_faq.html#sec_faq_update_reg_rtos", [
        [ "Updating of registers with an RTOS and locking:", "sec_faq.html#sec_faq_update_reg_rtos_simple", null ],
        [ "Updating of registers with an RTOS and message queues:", "sec_faq.html#sec_faq_update_reg_rtos_msg", null ],
        [ "Can you tell me something about the design of the MODBUS stack?", "sec_faq.html#sec_faq_design_basic", null ]
      ] ]
    ] ],
    [ "Porting the MODBUS stack", "sec_porting.html", [
      [ "Build system", "sec_porting.html#sec_porting_build", null ],
      [ "Platform specifics (mbport.h)", "sec_porting.html#sec_porting_ospecific", null ],
      [ "Implementation of timers (mbporttimer.c)", "sec_porting.html#sec_porting_timers", null ],
      [ "Implementation of serial functions (mbportserial.c)", "sec_porting.html#sec_porting_serial", null ],
      [ "Event queue (mbportevent.c)", "sec_porting.html#sec_porting_event", null ],
      [ "Customizing the stack", "sec_porting.html#sec_porting_customize", null ]
    ] ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ],
        [ "Enumerator", "functions_eval.html", null ]
      ] ]
    ] ],
    [ "Examples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"AVR-ATMEGA_ATMELSTUDIO_BARE_2demo_8c-example.html",
"structxMBSInternalHandle__tag.html#a554d70d35aa5f5a005b1dfd9e4262ad7"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
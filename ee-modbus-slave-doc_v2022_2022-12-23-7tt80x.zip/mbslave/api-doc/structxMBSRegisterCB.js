var structxMBSRegisterCB =
[
    [ "peMBSCoilsCB", "structxMBSRegisterCB.html#a88356f6ea137b4a1c9046c8b81f8cfb5", null ],
    [ "peMBSDiscInputCB", "structxMBSRegisterCB.html#a8a1ad42ac635b7cb1117f8ff20acde5d", null ],
    [ "peMBSFileRecordCB", "structxMBSRegisterCB.html#a5e7f886d68330d1a73658cb6299b2398", null ],
    [ "peMBSRegHoldingCB", "structxMBSRegisterCB.html#a33c9e0e53c42e862ee6a6d3625ec873b", null ],
    [ "peMBSRegInputCB", "structxMBSRegisterCB.html#aba5a6f645e0c9bd7336680f0902d0bf1", null ]
];
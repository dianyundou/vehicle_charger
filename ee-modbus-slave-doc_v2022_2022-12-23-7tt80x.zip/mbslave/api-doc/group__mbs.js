var group__mbs =
[
    [ "MODBUS Configuration", "group__mbs__cfg.html", "group__mbs__cfg" ],
    [ "peMBSCoilCB", "group__mbs.html#ga89cddb4271268166a3ee15719de8eb3c", null ],
    [ "peMBSDiscreteInputCB", "group__mbs.html#ga99a52dca1946c5fafa23cd43bab6bcc6", null ],
    [ "peMBSFileRecordCB", "group__mbs.html#ga46615e1f7b70ca630ebe9ce164cfda25", null ],
    [ "peMBSGatewayCB", "group__mbs.html#ga229333b9a3a56a70f06b120345cfb7cf", null ],
    [ "peMBSRegisterHoldingCB", "group__mbs.html#ga2b94925840aff52541bf2d72c59e5ef0", null ],
    [ "peMBSRegisterInputCB", "group__mbs.html#gaf020ca8acfe78d20af9b82cc4ab78c01", null ],
    [ "peMBSSerialDiagCB", "group__mbs.html#ga79befdd3b494078c30c800ed0a35d1f0", null ],
    [ "xMBSHandle", "group__mbs.html#ga339ff42026e1f4de95e075f23965701e", null ],
    [ "eMBSRegisterMode", "group__mbs.html#gaa80b473862468eef85cf87631abc50b1", [
      [ "MBS_REGISTER_WRITE", "group__mbs.html#ggaa80b473862468eef85cf87631abc50b1a3e825eb579472c67f2554ded7af4ea78", null ],
      [ "MBS_REGISTER_READ", "group__mbs.html#ggaa80b473862468eef85cf87631abc50b1a54bdc72de92690780eedf1fc7c8414d1", null ]
    ] ],
    [ "eMBSSerialDiagQueryType_t", "group__mbs.html#ga657a41a24ca9c955cd10dbaf799a9955", null ],
    [ "eMBSClose", "group__mbs.html#ga98aa708f564350bd3fcbc7bd5b3db21e", null ],
    [ "eMBSGetRequestSlaveAddress", "group__mbs.html#ga7ffb424c909b355b19f4be2624d57f36", null ],
    [ "eMBSGetStatistics", "group__mbs.html#gaa1467a986f58b1531add861de94e2f15", null ],
    [ "eMBSPoll", "group__mbs.html#ga672c53b1099669251fa661256f0bc395", null ],
    [ "eMBSRegisterCoilCB", "group__mbs.html#gadd5ad58d7db66364cc0c771c5798f4f9", null ],
    [ "eMBSRegisterDiscreteCB", "group__mbs.html#ga9cdfa8865f034c17152346d5c7286e9d", null ],
    [ "eMBSRegisterFileRecordCB", "group__mbs.html#gae9319b90d6eba182105c54e1bfd69fe4", null ],
    [ "eMBSRegisterFunctionCB", "group__mbs.html#ga1824ed0d733cdc729b37bd613fc9bbe1", null ],
    [ "eMBSRegisterGatewayCB", "group__mbs.html#ga18f296d5f1620b3de2164c74a69e4f5b", null ],
    [ "eMBSRegisterHoldingCB", "group__mbs.html#gad3d08582e4977362d56c4fd610430d06", null ],
    [ "eMBSRegisterInputCB", "group__mbs.html#ga188c98cd3da9c9f5f9b7d8f4586a1c78", null ],
    [ "eMBSRegisterProtAnalyzer", "group__mbs.html#ga5ac779de9393a0af5b0a2f2a6fc1935b", null ],
    [ "eMBSRegisterSerialDiagCB", "group__mbs.html#ga6bebf54e48c101a74e37904d55b27343", null ],
    [ "eMBSResetStatistics", "group__mbs.html#ga61d23aacef7d4d2108cee6cd779c9256", null ],
    [ "eMBSSerialInit", "group__mbs.html#ga71d4903325858d6b0f7be38b32d94d75", null ],
    [ "eMBSSerialInitExt", "group__mbs.html#ga38962c8be5fb6a581a22b151b56209c3", null ],
    [ "eMBSTCPSetGatewayMode", "group__mbs.html#ga3d49c7cd514af65313b6a0bc833f988e", null ]
];